import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../types';

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      text: "Hello! I am your FastPay Treasury & Compliance AI assistant. I can help explain our Stellar network anchor channels, BNR compliance frameworks, or multi-sig approval mechanisms. Ask me anything!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom on new messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMsg: Message = {
      role: 'user',
      text: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      // Structure conversation history for server-side Gemini processing
      const conversationHistory = messages.map(m => ({
        role: m.role,
        text: m.text
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMsg.text,
          history: conversationHistory
        })
      });

      if (res.ok) {
        const data = await res.json();
        const modelMsg: Message = {
          role: 'model',
          text: data.text || "I was unable to process your request.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, modelMsg]);
      } else {
        throw new Error("API rejection");
      }
    } catch (err) {
      // Fallback response with helpful FastPay guidance
      const fallbackMsg: Message = {
        role: 'model',
        text: "I encountered a transient network connection issue. However, you are exploring the FastPay payment corridors! We combine Stellar anchor liquidity with automated RWF payout rails to MTN MoMo and Airtel Mobile wallets, validating all dispatches via multi-sig approvals safely.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, fallbackMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-[100] font-sans" id="chatbot-assistant">
      
      {/* Pulse Flow Toggle Action Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-[#4472ca] hover:bg-[#5E7CE2] text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all cursor-pointer ai-fab-glow"
        id="ai-toggle-fab"
      >
        <span className="material-symbols-outlined text-2xl">auto_awesome</span>
      </button>

      {/* Floating Chat Box Modals */}
      {isOpen && (
        <div 
          className="absolute bottom-18 right-0 w-80 sm:w-96 glass-card rounded-2xl flex flex-col shadow-2xl border-2 border-[#5E7CE2]/30 overflow-hidden"
          id="ai-assistant-modal"
        >
          {/* Box Header */}
          <header className="bg-[#1e1f25] px-4 py-3 border-b border-[#5E7CE2]/20 flex items-center justify-between text-left">
            <div className="flex items-center gap-2 text-[#aec6ff]">
              <span className="material-symbols-outlined text-lg">smart_toy</span>
              <span className="text-xs font-bold uppercase tracking-wider">
                FastPay Assistant (Gemini)
              </span>
            </div>
            
            <button 
              onClick={() => setIsOpen(false)}
              className="material-symbols-outlined text-[#c3c6d4] hover:text-white cursor-pointer text-base p-0.5 rounded hover:bg-[#111319]"
            >
              close
            </button>
          </header>

          {/* Conversation Bubble body stream */}
          <div className="h-72 overflow-y-auto p-4 space-y-4 bg-[#0c0e13]/60">
            {messages.map((m, idx) => {
              const isUser = m.role === 'user';
              return (
                <div 
                  key={idx}
                  className={`flex gap-2.5 max-w-[85%] text-left ${isUser ? 'ml-auto flex-row-reverse' : ''}`}
                >
                  {/* Small circle avatar indicators */}
                  {!isUser && (
                    <div className="w-7 h-7 rounded-full bg-[#5E7CE2]/10 border border-[#5E7CE2]/30 flex items-center justify-center shrink-0 text-[#aec6ff]">
                      <span className="material-symbols-outlined text-xs">smart_toy</span>
                    </div>
                  )}

                  <div className="space-y-1">
                    <div className={`p-3 rounded-2xl text-[11px] leading-relaxed shadow-md ${
                      isUser 
                        ? 'bg-[#4472ca] text-white rounded-tr-none' 
                        : 'bg-[#1e1f25]/90 border border-[#434752]/25 text-white rounded-tl-none'
                    }`}>
                      {m.text}
                    </div>
                    <p className={`text-[8px] font-mono text-[#c3c6d4]/60 ${isUser ? 'text-right' : 'text-left'}`}>
                      {m.timestamp}
                    </p>
                  </div>
                </div>
              );
            })}

            {isTyping && (
              <div className="flex gap-2.5 max-w-[85%] text-left">
                <div className="w-7 h-7 rounded-full bg-[#5E7CE2]/10 border border-[#5E7CE2]/30 flex items-center justify-center shrink-0 text-[#aec6ff]">
                  <span className="material-symbols-outlined text-xs">smart_toy</span>
                </div>
                <div className="bg-[#1e1f25]/90 border border-[#434752]/25 p-3 rounded-2xl rounded-tl-none flex items-center gap-1.5 shadow-md">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#aec6ff] animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-1.5 h-1.5 rounded-full bg-[#aec6ff] animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-1.5 h-1.5 rounded-full bg-[#aec6ff] animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Bottom input section */}
          <form 
            onSubmit={handleSubmit}
            className="p-3 bg-[#1e1f25] border-t border-[#434752]/20 relative"
          >
            <input 
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about settlement rates or multi-sig policies..."
              className="w-full bg-[#0c0e13] border border-[#434752]/40 rounded-full py-2.5 pl-4 pr-11 text-xs text-white custom-input outline-none font-sans"
              disabled={isTyping}
            />

            <button 
              type="submit"
              disabled={!input.trim() || isTyping}
              className="absolute right-4.5 top-1/2 -translate-y-1/2 text-[#aec6ff] hover:text-white disabled:opacity-30 cursor-pointer p-1"
            >
              <span className="material-symbols-outlined text-lg leading-none">send</span>
            </button>
          </form>

        </div>
      )}

    </div>
  );
}
