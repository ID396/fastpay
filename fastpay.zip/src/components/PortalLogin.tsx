import React, { useState } from 'react';
import { Tab } from '../types';
import { Language } from './LanguageSelector';
import { getTranslations } from '../locales';

interface PortalLoginProps {
  setCurrentTab: (tab: Tab) => void;
  onLoginSuccess: (fullName: string, organisation: string) => void;
  currentLanguage: Language;
}

export default function PortalLogin({ setCurrentTab, onLoginSuccess, currentLanguage }: PortalLoginProps) {
  const t = getTranslations(currentLanguage.code);
  const [username, setUsername] = useState('theogene@kigali.rw');
  const [password, setPassword] = useState('password123');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMess, setErrorMess] = useState('');

  // Modals & form state
  const [registerOpen, setRegisterOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);

  // Register Fields
  const [regName, setRegName] = useState('');
  const [regRegion, setRegRegion] = useState('Kigali Hub');
  const [regLicense, setRegLicense] = useState('');
  const [regAnchor, setRegAnchor] = useState('');
  const [regReserves, setRegReserves] = useState('15000000');
  const [regLoading, setRegLoading] = useState(false);
  const [regSuccess, setRegSuccess] = useState(false);
  const [registeredCorridor, setRegisteredCorridor] = useState<any>(null);

  // Support Ticket Fields
  const [supInstitution, setSupInstitution] = useState('');
  const [supSeverity, setSupSeverity] = useState<'Critical' | 'Major' | 'Minor'>('Minor');
  const [supContact, setSupContact] = useState('');
  const [supMessage, setSupMessage] = useState('');
  const [supLoading, setSupLoading] = useState(false);
  const [supSuccess, setSupSuccess] = useState(false);
  const [submittedTicket, setSubmittedTicket] = useState<any>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setErrorMess('Please enter your credentials.');
      return;
    }
    
    setIsLoading(true);
    setErrorMess('');

    // Simulate login validation
    setTimeout(() => {
      setIsLoading(false);
      // Log in as Theogene Rukundo from Bank of Kigali
      onLoginSuccess("Theogene Rukundo", "Bank of Kigali");
      setCurrentTab('dashboard');
    }, 1200);
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regAnchor) {
      alert("Please enter the Corridor Name and Stellar Anchor Address.");
      return;
    }

    setRegLoading(true);
    try {
      const res = await fetch('/api/corridors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: regName,
          region: regRegion,
          licenseCode: regLicense,
          stellarAnchor: regAnchor,
          initialReserves: regReserves
        })
      });

      if (res.ok) {
        const data = await res.json();
        setRegisteredCorridor(data.corridor);
        setRegSuccess(true);
      } else {
        const data = await res.json();
        alert(data.error || "Failed to register institution.");
      }
    } catch (err) {
      alert("Network error. Failed to connect to FastPay registry DB.");
    } finally {
      setRegLoading(false);
    }
  };

  const handleSupportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supInstitution || !supContact || !supMessage) {
      alert("Please fill in all requested helpline fields.");
      return;
    }

    setSupLoading(true);
    try {
      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          institutionName: supInstitution,
          severity: supSeverity,
          contact: supContact,
          message: supMessage
        })
      });

      if (res.ok) {
        const data = await res.json();
        setSubmittedTicket(data.ticket);
        setSupSuccess(true);
      } else {
        const data = await res.json();
        alert(data.error || "Failed to submit emergency ticket.");
      }
    } catch (err) {
      alert("Network error. Failed to dispatch ticket.");
    } finally {
      setSupLoading(false);
    }
  };

  const handleImmediateLogin = () => {
    if (registeredCorridor) {
      onLoginSuccess("Treasury Officer", registeredCorridor.name);
      setCurrentTab('dashboard');
    }
  };

  return (
    <div className="bg-mesh min-h-screen flex flex-col font-sans text-[#e2e2ea] relative pt-24 pb-12" id="login-page">
      
      <main className="flex-grow flex items-center justify-center px-4">
        <div className="w-full max-w-[480px] space-y-8 z-10">
          
          {/* Main Login Card */}
          <div className="glass-card rounded-2xl p-8 md:p-10 shadow-2xl relative overflow-hidden">
            {/* Decorative Top Highlight */}
            <div className="absolute top-0 right-0 -mr-16 -mt-16 w-32 h-32 bg-[#aec6ff]/10 rounded-full blur-3xl" />
            
            <div className="relative z-10 text-left">
              <header className="mb-8 space-y-2">
                <h1 className="text-2xl md:text-3xl font-bold font-sans text-[#aec6ff] tracking-tight">
                  {t.institutionalAccess}
                </h1>
                <p className="text-xs text-[#c3c6d4] leading-relaxed">
                  {t.loginSub}
                </p>
              </header>

              {errorMess && (
                <div className="bg-[#93000a]/30 border border-[#93000a] text-xs text-[#ffdad6] px-4 py-3 rounded-lg mb-4">
                  {errorMess}
                </div>
              )}

              <form className="space-y-6" onSubmit={handleSubmit}>
                
                {/* Email input field */}
                <div className="space-y-2">
                  <label className="text-xs font-mono font-medium text-[#c3c6d4] ml-1 block" htmlFor="id">
                    {t.usernameField}
                  </label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-[#8d909d] text-lg">
                      person
                    </span>
                    <input 
                      className="w-full bg-[#CFDEE7]/10 focus:bg-[#CFDEE7]/15 border border-[#434752]/40 rounded-xl py-3.5 pl-12 pr-4 text-xs text-[#e2e2ea] custom-input font-medium placeholder:text-[#8d909d]/50" 
                      id="id" 
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="darius@wallet.rw" 
                      type="text"
                    />
                  </div>
                </div>

                {/* Password input field */}
                <div className="space-y-2">
                  <label className="text-xs font-mono font-medium text-[#c3c6d4] ml-1 block" htmlFor="password">
                    {t.passwordField}
                  </label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-[#8d909d] text-lg">
                      lock
                    </span>
                    <input 
                      className="w-full bg-[#CFDEE7]/10 focus:bg-[#CFDEE7]/15 border border-[#434752]/40 rounded-xl py-3.5 pl-12 pr-12 text-xs text-[#e2e2ea] custom-input font-medium placeholder:text-[#8d909d]/50" 
                      id="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••••••" 
                      type={showPassword ? "text" : "password"}
                    />
                    <button 
                      className="material-symbols-outlined absolute right-4 top-1/2 -translate-y-1/2 text-[#8d909d] hover:text-[#aec6ff] transition-colors cursor-pointer text-lg p-1" 
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? "visibility_off" : "visibility"}
                    </button>
                  </div>
                </div>

                {/* Remember/Forgot controllers */}
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <input 
                      className="w-4 h-4 rounded border-[#434752]/50 bg-[#CFDEE7]/10 text-[#173da4] focus:ring-[#aec6ff]/20 cursor-pointer" 
                      type="checkbox"
                      defaultChecked
                    />
                    <span className="text-[11px] font-mono font-medium text-[#c3c6d4] group-hover:text-white transition-colors">
                      {t.rememberMachine}
                    </span>
                  </label>
                  <a 
                    className="text-[11px] font-mono font-medium text-[#5E7CE2] hover:underline" 
                    href="#"
                    onClick={(e) => e.preventDefault()}
                  >
                    {t.forgotPassword}
                  </a>
                </div>

                {/* Submit trigger */}
                <button 
                  className="w-full bg-[#4472ca] hover:bg-[#5E7CE2] text-white font-semibold text-sm py-3.5 rounded-xl transition-all duration-200 active:scale-[0.98] shadow-lg shadow-[#4472ca]/20 flex items-center justify-center gap-2 cursor-pointer"
                  type="submit"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                      {t.loadingTokenGate}
                    </>
                  ) : (
                    <>
                      <span className="material-symbols-outlined text-sm">vpn_key</span>
                      {t.signInPortalBtn}
                    </>
                  )}
                </button>

              </form>

              {/* Alternative items */}
              <div className="mt-8 pt-8 border-t border-[#434752]/20 space-y-4">
                <div className="flex flex-col gap-3">
                  <button 
                    onClick={() => {
                      setRegSuccess(false);
                      setRegisteredCorridor(null);
                      setRegisterOpen(true);
                    }}
                    className="flex items-center justify-center gap-2 py-3 px-4 border border-[#434752]/30 rounded-xl hover:bg-[#33353b]/40 text-xs font-mono font-medium text-white transition-all cursor-pointer animate-pulse"
                  >
                    <span className="material-symbols-outlined text-[#5E7CE2] text-sm">domain_add</span>
                    {t.registerInstruction}
                  </button>
                  
                  <button 
                    onClick={() => {
                      setSupSuccess(false);
                      setSubmittedTicket(null);
                      setSupportOpen(true);
                    }}
                    className="flex items-center justify-center gap-2 py-3 px-4 border border-[#434752]/30 rounded-xl hover:bg-[#33353b]/40 text-xs font-mono font-medium text-white transition-all cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[#5E7CE2] text-sm">support_agent</span>
                    {t.emergencySupport}
                  </button>
                </div>
              </div>

            </div>
          </div>

          {/* Trusted Networks logos */}
          <div className="space-y-4 pt-4">
            <p className="text-center text-[10px] font-mono font-semibold text-[#c3c6d4]/60 uppercase tracking-widest leading-none">
              Trusted by Mobile Money Networks
            </p>
            <div className="flex justify-center items-center gap-10 opacity-70 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-500">
              <img 
                src="https://lh3.googleusercontent.com/aida/ADBb0ugAiZHo0Qf-Pf4_DYX37EfvGCdhDD0QXuEGDx96sESBs5QheAQmaLRrr7D0AUkdNu5KjKMhXymumTe1atdjF_P-L8FAN3k_sYAYtq1np-nOWTVN2IQo7nifh2CYYyNP-ZD-d6Wop5aqkkGmGwau2r5sqXQ4Jjym2n95bWpHBrrUUgKQlpnnzutt_0csdVpjuj-cNO1UP1jziTxfEqt-rnUmQt2W3MZlsxl4dnNhhHud5TKG8E09GH3s688Muxwmvilw7odvQrAm0Q" 
                alt="Airtel Money Logo" 
                className="h-7 w-auto opacity-80"
              />
              <img 
                src="https://lh3.googleusercontent.com/aida/ADBb0uiHArgGudXlSCD_vVes5W1ADII5YWqoG6Ab9BoK4oOPAUspweoux45SmPBnScSgLN4nyaJeeJtZd1FInbkq7PBdo6ONn9K9aJQ-IKIIcx1sYdMdCTiliUbYK10xilgO7A6Tz2AcCRTc_yiLSbmp2rCeQcH-31UEvuG08_WnfT-Yg-i2NsXYmGlpShWh-2maNg_IZub48RmqO5LLK4BmUG10NGFLtRCoJgQQ_dYiMmJrONe5T2HZBiwruXVbUwkzEmWMtVYCLK_OxRU" 
                alt="MTN MoMo Logo" 
                className="h-7 w-auto opacity-80"
              />
            </div>
            
            {/* Certifications footer badges */}
            <div className="flex justify-center items-center gap-6 opacity-40 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-500 pt-4">
              <div className="flex items-center gap-1.5 text-white">
                <span className="material-symbols-outlined text-[14px]">verified</span>
                <span className="text-[10px] font-mono tracking-wider uppercase">Stellar Network</span>
              </div>
              <div className="flex items-center gap-1.5 text-white">
                <span className="material-symbols-outlined text-[14px]">security</span>
                <span className="text-[10px] font-mono tracking-wider uppercase">PCI DSS Compliant</span>
              </div>
            </div>
          </div>

        </div>
      </main>

      {/* CREATE CUSTOMER ACCOUNT MODAL DIALOG SHEET */}
      {registerOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center z-50 px-4">
          <div className="bg-[#111319] border border-[#5E7CE2]/30 max-w-md w-full rounded-2xl overflow-hidden shadow-2xl animate-fade-in relative text-left">
            <header className="p-6 bg-[#1e1f25] border-b border-[#434752]/30 flex justify-between items-center">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#aec6ff]">person_add</span>
                  Create Personal Customer Account
                </h3>
                <p className="text-[10px] text-[#c3c6d4]/80 mt-1 font-mono">Register instantly to access your secure onramp/offramp conversion dashboard</p>
              </div>
              <button 
                onClick={() => setRegisterOpen(false)}
                className="material-symbols-outlined text-[#c3c6d4] hover:text-white cursor-pointer"
              >
                close
              </button>
            </header>

            {!regSuccess ? (
              <form onSubmit={handleRegisterSubmit} className="p-6 space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-medium text-slate-400">Your Full Name</label>
                  <input 
                    type="text" 
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="e.g. Darius Rukundo, Marie Chantal"
                    className="w-full bg-[#CFDEE7]/10 focus:bg-[#CFDEE7]/15 border border-[#434752]/40 rounded-xl py-3 px-4 text-xs text-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-medium text-slate-400">Primary Exchange Asset</label>
                    <select 
                      value={regRegion}
                      onChange={(e) => setRegRegion(e.target.value)}
                      className="w-full bg-[#1e1f25] border border-[#434752]/40 rounded-xl py-3 px-4 text-xs text-white"
                    >
                      <option value="Kigali Hub">RWF Wallet</option>
                      <option value="USD Wallet">USD Wallet</option>
                      <option value="BTC Wallet">Bitcoin Wallet</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-medium text-slate-400">Username / Email</label>
                    <input 
                      type="text" 
                      value={regLicense}
                      onChange={(e) => setRegLicense(e.target.value)}
                      placeholder="e.g. name@domain.com"
                      className="w-full bg-[#CFDEE7]/10 focus:bg-[#CFDEE7]/15 border border-[#434752]/40 rounded-xl py-3 px-4 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-medium text-slate-400">Bitcoin (BTC) External Wallet Key (for conversion payoffs)</label>
                  <input 
                    type="text" 
                    required
                    value={regAnchor}
                    onChange={(e) => setRegAnchor(e.target.value)}
                    placeholder="e.g. bc1qxy2kgdygjrsq... (Bitcoin Address)"
                    className="w-full bg-[#CFDEE7]/10 focus:bg-[#CFDEE7]/15 border border-[#434752]/40 rounded-xl py-3 px-4 text-xs text-white font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-medium text-slate-400">Initial Funding Deposit (RWF)</label>
                  <input 
                    type="number"
                    value={regReserves}
                    onChange={(e) => setRegReserves(e.target.value)}
                    placeholder="e.g. 500000"
                    className="w-full bg-[#CFDEE7]/10 focus:bg-[#CFDEE7]/15 border border-[#434752]/40 rounded-xl py-3 px-4 text-xs text-white font-mono"
                  />
                </div>

                <div className="bg-[#aec6ff]/5 p-4 rounded-xl border border-blue-900/30 text-[11px] text-[#c3c6d4] leading-relaxed">
                  <span className="font-bold text-white block mb-0.5">Note:</span>
                  Submitting will create your customer profile and credit your demo balances immediately with verified cross-assets.
                </div>

                <footer className="pt-3 border-t border-slate-800 flex justify-end gap-3">
                  <button 
                    type="button" 
                    onClick={() => setRegisterOpen(false)}
                    className="px-4 py-2 border border-[#8d909d]/30 text-xs rounded-xl hover:bg-white/5 font-mono cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    disabled={regLoading}
                    className="px-5 py-2 bg-[#4472ca] hover:bg-[#5E7CE2] text-white font-semibold text-xs rounded-xl cursor-pointer"
                  >
                    {regLoading ? "Registering..." : "Activate Account"}
                  </button>
                </footer>
              </form>
            ) : (
              <div className="p-6 text-center space-y-6">
                <div className="w-16 h-16 bg-green-500/10 border border-green-500/30 rounded-full flex items-center justify-center mx-auto text-green-400">
                  <span className="material-symbols-outlined text-3xl">done_all</span>
                </div>
                <div>
                  <h4 className="font-bold text-white text-base">Customer Profile Activated!</h4>
                  <p className="text-xs text-[#c3c6d4] mt-2 leading-relaxed">
                    Your personal wallet <strong>{registeredCorridor?.id}</strong> is now live. Initial balance of <strong>{parseInt(registeredCorridor?.initialReserves || '50000').toLocaleString()} RWF</strong> has been matched to your customer keys on Stellar.
                  </p>
                </div>

                <div className="bg-[#1e1f25] p-3 rounded-xl border border-slate-800 text-left font-mono text-[10px] text-blue-400 space-y-1">
                  <div><strong>Wallet ID:</strong> {registeredCorridor?.id}</div>
                  <div><strong>Customer Name:</strong> {registeredCorridor?.name}</div>
                  <div><strong>Primary Asset:</strong> {registeredCorridor?.region}</div>
                  <div><strong>Public Address:</strong> {registeredCorridor?.stellarAnchor}</div>
                </div>

                <div className="flex flex-col gap-2 pt-2">
                  <button 
                    onClick={handleImmediateLogin}
                    className="w-full py-3 bg-green-600 hover:bg-green-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-green-900/10 animate-[bounce_2s_infinite]"
                  >
                    <span className="material-symbols-outlined text-sm">login</span>
                    Access & Launch My Dashboard Immediately
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setRegisterOpen(false)}
                    className="w-full py-2 px-4 border border-slate-800 text-xs text-slate-400 hover:text-white rounded-xl cursor-pointer"
                  >
                    Return to Login Gate
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* EMERGENCY SUPPORT INCIDENT MODAL DIALOG SHEET */}
      {supportOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center z-50 px-4">
          <div className="bg-[#111319] border border-rose-500/30 max-w-md w-full rounded-2xl overflow-hidden shadow-2xl animate-fade-in relative text-left">
            <header className="p-6 bg-[#1e1f25] border-b border-[#434752]/30 flex justify-between items-center">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <span className="material-symbols-outlined text-rose-400">support_agent</span>
                  Emergency Support Hotline
                </h3>
                <p className="text-[10px] text-slate-400 mt-1 font-mono">24/7 priority routing channel for banking compliance and technical issues</p>
              </div>
              <button 
                onClick={() => setSupportOpen(false)}
                className="material-symbols-outlined text-[#c3c6d4] hover:text-white cursor-pointer"
              >
                close
              </button>
            </header>

            {!supSuccess ? (
              <form onSubmit={handleSupportSubmit} className="p-6 space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-medium text-slate-400">Affected Institution / Corridor</label>
                  <input 
                    type="text" 
                    required
                    value={supInstitution}
                    onChange={(e) => setSupInstitution(e.target.value)}
                    placeholder="e.g. Bank of Kigali, Standard Bank"
                    className="w-full bg-[#CFDEE7]/10 focus:bg-[#CFDEE7]/15 border border-[#434752]/40 rounded-xl py-3 px-4 text-xs text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-medium text-slate-400">Incident Severity Status</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['Critical', 'Major', 'Minor'] as const).map((sev) => (
                      <button
                        key={sev}
                        type="button"
                        onClick={() => setSupSeverity(sev)}
                        className={`py-2 px-3 rounded-lg border text-xs font-semibold uppercase transition-all cursor-pointer ${
                          supSeverity === sev
                            ? sev === 'Critical'
                              ? 'bg-rose-500/15 border-rose-500 text-rose-400'
                              : sev === 'Major'
                              ? 'bg-amber-500/15 border-amber-500 text-amber-400'
                              : 'bg-blue-500/15 border-blue-500 text-blue-400'
                            : 'bg-slate-900/60 border-slate-800 text-slate-400'
                        }`}
                      >
                        {sev}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-medium text-slate-400">Contact Officer Email / Hotline Phone</label>
                  <input 
                    type="text" 
                    required
                    value={supContact}
                    onChange={(e) => setSupContact(e.target.value)}
                    placeholder="e.g. support@kigali.rw or +250..."
                    className="w-full bg-[#CFDEE7]/10 focus:bg-[#CFDEE7]/15 border border-[#434752]/40 rounded-xl py-3 px-4 text-xs text-white font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-medium text-slate-400">Incident Description / Technical Message</label>
                  <textarea 
                    rows={3}
                    required
                    value={supMessage}
                    onChange={(e) => setSupMessage(e.target.value)}
                    placeholder="Provide specific details about transaction IDs or anchor errors encountered..."
                    className="w-full bg-[#CFDEE7]/10 focus:bg-[#CFDEE7]/15 border border-[#434752]/40 rounded-xl py-3 px-4 text-xs text-white leading-relaxed"
                  />
                </div>

                <div className="bg-rose-500/5 p-4 rounded-xl border border-rose-900/30 text-[11px] text-slate-400 leading-relaxed">
                  <span className="font-bold text-rose-400 block mb-0.5">Priority Desk Notice:</span>
                  Critical level issues will trigger direct SMS alerts to on-duty treasury officers Sarah Kamau and Jean Pierre.
                </div>

                <footer className="pt-3 border-t border-slate-800 flex justify-end gap-3">
                  <button 
                    type="button" 
                    onClick={() => setSupportOpen(false)}
                    className="px-4 py-2 border border-[#8d909d]/30 text-xs rounded-xl hover:bg-white/5 font-mono cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    disabled={supLoading}
                    className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs rounded-xl cursor-pointer"
                  >
                    {supLoading ? "Submitting..." : "Dispatch Alert"}
                  </button>
                </footer>
              </form>
            ) : (
              <div className="p-6 text-center space-y-6">
                <div className="w-16 h-16 bg-rose-500/10 border border-rose-500/30 rounded-full flex items-center justify-center mx-auto text-rose-400">
                  <span className="material-symbols-outlined text-3xl">priority_high</span>
                </div>
                <div>
                  <h4 className="font-bold text-white text-base">Emergency Ticket Dispatched!</h4>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    Ticket <strong>{submittedTicket?.id}</strong> is registered. Our SLA guarantees a callback support response to <strong>{submittedTicket?.contact}</strong> in under 5 minutes.
                  </p>
                </div>

                <div className="bg-[#1e1f25] p-3 rounded-xl border border-rose-900/20 text-left font-mono text-[10px] text-rose-400 space-y-1">
                  <div><strong>Ticket ID:</strong> {submittedTicket?.id}</div>
                  <div><strong>Severity Status:</strong> {submittedTicket?.severity}</div>
                  <div><strong>Contact Address:</strong> {submittedTicket?.contact}</div>
                  <div><strong>Logged Alert:</strong> "{submittedTicket?.message}"</div>
                </div>

                <div className="flex flex-col gap-2 pt-2">
                  <button 
                    type="button" 
                    onClick={() => setSupportOpen(false)}
                    className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl cursor-pointer"
                  >
                    Acknowledge & Close
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
