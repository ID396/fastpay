import { useState, useEffect } from 'react';
import { Tab } from '../types';
import { Language } from './LanguageSelector';
import { getTranslations } from '../locales';
import LightningLogo from './LightningLogo';

interface LandingPageProps {
  setCurrentTab: (tab: Tab) => void;
  currentLanguage: Language;
}

interface NodeDetail {
  name: string;
  status: 'Operational' | 'Maintenance' | 'Backup';
  uptime: string;
  reserves: string;
  connections: number;
}

export default function LandingPage({ setCurrentTab, currentLanguage }: LandingPageProps) {
  const t = getTranslations(currentLanguage.code);
  const [rates, setRates] = useState({ btc_rwf: 85002400 });
  const [activeNode, setActiveNode] = useState<NodeDetail>({
    name: "Kigali Main Hub",
    status: "Operational",
    uptime: "99.99%",
    reserves: "52,000,000 RWF",
    connections: 142
  });

  const nodes: { id: string; name: string; x: string; y: string; detail: NodeDetail }[] = [
    {
      id: "kigali",
      name: "Kigali Hub",
      x: "53%",
      y: "48%",
      detail: {
        name: "Kigali Main Hub",
        status: "Operational",
        uptime: "99.99%",
        reserves: "52,000,000 RWF",
        connections: 142
      }
    },
    {
      id: "rubavu",
      name: "Rubavu Node",
      x: "15%",
      y: "32%",
      detail: {
        name: "Rubavu Western Border Node",
        status: "Operational",
        uptime: "99.91%",
        reserves: "14,500,000 RWF",
        connections: 48
      }
    },
    {
      id: "musanze",
      name: "Musanze Hub",
      x: "38%",
      y: "21%",
      detail: {
        name: "Musanze Northern Anchor",
        status: "Operational",
        uptime: "100.00%",
        reserves: "22,100,000 RWF",
        connections: 84
      }
    },
    {
      id: "huye",
      name: "Huye Node",
      x: "34%",
      y: "78%",
      detail: {
        name: "Huye Southern Corridor",
        status: "Backup",
        uptime: "99.85%",
        reserves: "8,900,000 RWF",
        connections: 32
      }
    },
    {
      id: "rwamagana",
      name: "Rwamagana Hub",
      x: "72%",
      y: "45%",
      detail: {
        name: "Rwamagana Eastern Region Hub",
        status: "Operational",
        uptime: "99.95%",
        reserves: "19,800,000 RWF",
        connections: 61
      }
    }
  ];

  // Fetch or simulate live rate updates
  useEffect(() => {
    const fetchRates = async () => {
      try {
        const res = await fetch('/api/rates');
        if (res.ok) {
          const data = await res.json();
          setRates(data);
        }
      } catch (err) {
        // Fallback simulation
        setRates({ btc_rwf: 85000000 + Math.floor((Math.random() - 0.5) * 40000) });
      }
    };

    fetchRates();
    const interval = setInterval(fetchRates, 5200);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-[#060913] min-h-screen text-white select-none relative" id="landing-page">
      
      {/* Mesh Background Overlay */}
      <div className="absolute inset-0 bg-mesh opacity-90 pointer-events-none z-0" />

      {/* Hero Content Section */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 pt-32 pb-16 text-center flex flex-col items-center">
        
        {/* Banner Pill */}
        <div 
          className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-[#111827]/60 border border-slate-800/80 mb-8 select-none"
          id="stellar-banner"
        >
          <span className="relative flex h-1.5 w-1.5 animate-pulse">
            <span className="absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#5E7CE2]"></span>
          </span>
          <span className="font-mono text-[9px] uppercase text-[#a1bfff] tracking-[0.2em] font-bold leading-none">
            STELLAR NETWORK POWERED
          </span>
        </div>

        {/* Big Displays Title */}
        <h1 
          className="text-4xl md:text-[52px] font-extrabold tracking-tight text-white max-w-4xl leading-[1.15] md:leading-[1.12] mb-6 font-sans capitalize animate-fade-in"
          id="hero-title"
        >
          Bitcoin In. Rwanda Francs Out. <br />
          <span className="text-[#a1bfff]">
            The Future of African Banking.
          </span>
        </h1>

        {/* Pitch Subtext */}
        <p 
          className="text-xs md:text-sm text-[#94a3b8] max-w-xl leading-relaxed mb-10 font-sans"
          id="hero-subtitle"
        >
          Leverage the Stellar blockchain to instantly deposit, swap, and withdraw funds between Bitcoin (BTC), USD, and Rwandan Francs (RWF) with minimal fees.
        </p>

        {/* Action Triggers */}
        <div className="flex flex-col sm:flex-row gap-4 mb-20 z-10">
          <button 
            onClick={() => setCurrentTab('login')}
            className="bg-[#2563eb] hover:bg-blue-600 text-white font-semibold text-xs px-6 py-3 rounded-lg transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2"
          >
            Start Accepting Crypto
          </button>
          
          <button 
            onClick={() => {
              const el = document.getElementById('map-explore');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="bg-[#0e131f]/40 border border-slate-800 hover:bg-white/5 text-slate-300 font-semibold text-xs px-6 py-3 rounded-lg transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2"
          >
            View Documentation
          </button>
        </div>

        {/* Live Ticker Panels */}
        <div 
          className="w-full max-w-4xl bg-[#0a0f1d]/70 border border-slate-800/80 rounded-xl p-5 grid grid-cols-1 md:grid-cols-3 gap-6 text-left z-10"
          id="ticker-widget"
        >
          {/* Rate Tracker */}
          <div className="flex items-center gap-3">
            <div className="p-2 w-9 h-9 bg-slate-900/60 rounded-lg text-blue-400 border border-slate-800/60 flex items-center justify-center">
              <span className="material-symbols-outlined text-base">show_chart</span>
            </div>
            <div>
              <p className="font-mono text-[8.5px] text-slate-500 uppercase tracking-widest font-bold leading-none">
                LIVE RATE
              </p>
              <p className="text-xs font-mono font-bold text-white tracking-wide mt-1.5 leading-none">
                1 BTC ≈ {rates.btc_rwf.toLocaleString()} RWF
              </p>
            </div>
          </div>

          {/* Divider lines in md breakpoints */}
          <div className="hidden md:block w-px h-8 bg-slate-800/80 self-center" />

          {/* Speed Indicator */}
          <div className="flex items-center gap-3 md:-ml-6">
            <div className="p-2 w-9 h-9 bg-slate-900/60 rounded-lg text-blue-400 border border-slate-800/60 flex items-center justify-center">
              <span className="material-symbols-outlined text-base">bolt</span>
            </div>
            <div>
              <p className="font-mono text-[8.5px] text-slate-500 uppercase tracking-widest font-bold leading-none">
                SETTLEMENT TIME
              </p>
              <p className="text-xs font-mono font-bold text-white tracking-wide mt-1.5 leading-none">
                &lt; 5 Seconds
              </p>
            </div>
          </div>

          <div className="hidden md:block w-px h-8 bg-slate-800/80 self-center" />

          {/* Security Indicator */}
          <div className="flex items-center gap-3 md:-ml-12">
            <div className="p-2 w-9 h-9 bg-slate-900/60 rounded-lg text-amber-600/75 border border-slate-800/60 flex items-center justify-center">
              <span className="material-symbols-outlined text-base">security</span>
            </div>
            <div>
              <p className="font-mono text-[8.5px] text-slate-500 uppercase tracking-widest font-bold leading-none">
                NETWORK STATUS
              </p>
              <p className="text-xs font-mono font-bold text-white tracking-wide mt-1.5 leading-none">
                Active (99.9%)
              </p>
            </div>
          </div>
        </div>

      </section>

      {/* Map Section */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 py-16" id="map-explore">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Left Column: Interactive Visual Map representation */}
          <div className="relative group">
            <div className="absolute -inset-4 bg-[#4472ca]/10 blur-3xl rounded-full opacity-60 group-hover:opacity-100 transition-opacity duration-1000 pointer-events-none" />
            <div className="glass-card rounded-2xl p-4 relative overflow-hidden aspect-[4/3] flex items-center justify-center border border-[#5E7CE2]/20">
              
              {/* Hotlinked stylized background Map of Rwanda */}
              <div className="absolute inset-0 grayscale opacity-40 group-hover:opacity-75 transition-all duration-700">
                <img 
                  alt="Active Banking Nodes Map" 
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuDDf2aJAFE-ahN6_cji30M5_eScjjcvcDOzxOk-PGZmD0iRkl0AbZUxpDyBiCj_73qmFRXXXphXebwI2XoR8Za1UUi8u57bTer-buNE2mjHXqiIE2oMlFqVaRq9i4yxVhacisdK-dShI-fu4CuHLvVewXObooEAbr_tC-XszY-whFeCbzgGFWE_xO2ZaNL3fhNr-ejtpzyCgyAerUYKLIel0Ii88yQakRUbX0Bxaepm5Ig5U6SyFquqBX0un8hWp_ZHhDqH_ukKssmn"
                />
              </div>

              {/* Glowing Connection lines representation */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
                <path 
                  d="M 15 32 Q 38 21 53 48" 
                  stroke="rgba(174, 198, 255, 0.15)" 
                  strokeWidth="2" 
                  fill="none" 
                  strokeDasharray="4 4"
                />
                <path 
                  d="M 38 21 Q 53 48 53 48" 
                  stroke="rgba(174, 198, 255, 0.15)" 
                  strokeWidth="2" 
                  fill="none" 
                  strokeDasharray="4 4"
                />
                <path 
                  d="M 34 78 Q 53 48 72 45" 
                  stroke="rgba(174, 198, 255, 0.15)" 
                  strokeWidth="2" 
                  fill="none" 
                  strokeDasharray="4 4"
                />
              </svg>

              {/* Mapping Interactive Markers */}
              {nodes.map((node) => {
                const isActive = activeNode.name.includes(node.name);
                return (
                  <button
                    key={node.id}
                    onClick={() => setActiveNode(node.detail)}
                    style={{ left: node.x, top: node.y }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 z-20 focus:outline-none cursor-pointer group/node"
                  >
                    <span className="relative flex items-center justify-center">
                      <span className={`absolute w-10 h-10 rounded-full animate-ping transition-all opacity-40 ${
                        isActive ? 'bg-[#ffb871]/40' : 'bg-[#4472ca]/20'
                      }`} />
                      <span className={`w-4 h-4 rounded-full border-2 border-white shadow-xl transition-all duration-300 scale-100 group-hover/node:scale-125 ${
                        isActive ? 'bg-[#ffb871]' : 'bg-[#4472ca]'
                      }`} />
                    </span>
                    
                    {/* Tiny tooltip indicator */}
                    <div className="absolute top-6 left-1/2 -translate-x-1/2 bg-[#1e1f25] border border-[#5E7CE2]/30 text-[10px] font-mono font-medium px-2 py-0.5 rounded shadow-xl whitespace-nowrap opacity-0 group-hover/node:opacity-100 pointer-events-none transition-opacity duration-200">
                      {node.name}
                    </div>
                  </button>
                );
              })}

              {/* Dynamic Bottom-Right Tooltip Status */}
              <div className="absolute bottom-6 right-6 glass-card p-4 rounded-xl border-[#5E7CE2]/40 max-w-[220px] transition-all duration-300 z-10 shadow-2xl">
                <p className="text-xs font-mono font-semibold text-[#aec6ff]">
                  {activeNode.name}
                </p>
                <div className="mt-1 flex items-center gap-1.5">
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    activeNode.status === 'Operational' ? 'bg-green-500' : 'bg-amber-500 animate-pulse'
                  }`} />
                  <p className="text-xs text-white font-medium">
                    Status: {activeNode.status}
                  </p>
                </div>
                <div className="mt-2 text-[10px] text-[#c3c6d4] font-mono space-y-0.5">
                  <p>Uptime: {activeNode.uptime}</p>
                  <p>Capacity: {activeNode.reserves}</p>
                </div>
              </div>

            </div>
          </div>

          {/* Right Column: Key Details */}
          <div className="space-y-6">
            <h2 className="text-3xl font-extrabold tracking-tight text-white font-sans text-left capitalize">
              Active Banking Nodes
            </h2>
            <p className="text-slate-400 text-sm leading-relaxed text-left">
              Our decentralized infrastructure spans across the 10 major economic zones of Rwanda. Each node ensures redundant pathing for crypto-to-fiat conversion, maintaining the highest uptime in African blockchain history.
            </p>

            <ul className="space-y-4 text-left">
              <li className="flex items-start gap-3">
                <span className="material-symbols-outlined text-[#3b82f6] mt-0.5 text-lg leading-none">
                  check_circle
                </span>
                <div>
                  <p className="font-semibold text-sm text-white">BNR Integrated</p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Direct integration with Rwanda's central banking rails for compliance.
                  </p>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <span className="material-symbols-outlined text-[#3b82f6] mt-0.5 text-lg leading-none">
                  check_circle
                </span>
                <div>
                  <p className="font-semibold text-sm text-white">Stellar Anchor Support</p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Standardized protocol for cross-border liquidity and settlement.
                  </p>
                </div>
              </li>
            </ul>

            <div className="pt-4 text-left">
              <button 
                onClick={() => {
                  const el = document.getElementById('mobile-payments');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-2 text-blue-400 hover:text-blue-300 font-mono text-xs tracking-wider uppercase font-semibold transition-all group cursor-pointer"
              >
                Explore Regional Network
                <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform text-sm">
                  arrow_forward
                </span>
              </button>
            </div>
          </div>

        </div>
      </section>

      {/* Direct-to-Mobile Money Section */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 py-20 border-t border-slate-900" id="mobile-payments">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-extrabold text-white mb-6">
            Direct-to-Mobile Settlement
          </h2>
          <p className="text-slate-400 text-sm max-w-2xl mx-auto leading-relaxed">
            Instantly offramp crypto assets directly into the region's leading mobile wallet networks with zero lag and native Stellar security mechanisms.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          
          {/* MTN MoMo Wallet Card */}
          <div className="bg-[#0b0f19]/60 hover:bg-[#111625] border border-slate-800 hover:border-blue-900/30 transition-all p-8 rounded-xl flex flex-col items-center justify-center text-center gap-4">
            <div className="w-16 h-16 rounded-xl overflow-hidden bg-[#ffcc00] p-1 flex items-center justify-center">
              <img 
                src="https://lh3.googleusercontent.com/aida/ADBb0uiHArgGudXlSCD_vVes5W1ADII5YWqoG6Ab9BoK4oOPAUspweoux45SmPBnScSgLN4nyaJeeJtZd1FInbkq7PBdo6ONn9K9aJQ-IKIIcx1sYdMdCTiliUbYK10xilgO7A6Tz2AcCRTc_yiLSbmp2rCeQcH-31UEvuG08_WnfT-Yg-i2NsXYmGlpShWh-2maNg_IZub48RmqO5LLK4BmUG10NGFLtRCoJgQQ_dYiMmJrONe5T2HZBiwruXVbUwkzEmWMtVYCLK_OxRU" 
                alt="MTN MoMo Logo" 
                className="w-full h-full object-contain rounded-lg"
              />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white font-sans">MTN MoMo</h3>
              <p className="font-mono text-[9px] font-bold text-blue-400 tracking-widest uppercase mt-1">
                INSTANT PAYOUT
              </p>
              <p className="text-xs text-slate-400 mt-2 max-w-xs leading-relaxed">
                Automated routing straight to any valid MTN Mobile Money wallet in Rwanda.
              </p>
            </div>
          </div>

          {/* Airtel Money Card */}
          <div className="bg-[#0b0f19]/60 hover:bg-[#111625] border border-slate-800 hover:border-blue-900/30 transition-all p-8 rounded-xl flex flex-col items-center justify-center text-center gap-4">
            <div className="w-16 h-16 rounded-xl overflow-hidden bg-[#e31937] p-1 flex items-center justify-center">
              <img 
                src="https://lh3.googleusercontent.com/aida/ADBb0ugAiZHo0Qf-Pf4_DYX37EfvGCdhDD0QXuEGDx96sESBs5QheAQmaLRrr7D0AUkdNu5KjKMhXymumTe1atdjF_P-L8FAN3k_sYAYtq1np-nOWTVN2IQo7nifh2CYYyNP-ZD-d6Wop5aqkkGmGwau2r5sqXQ4Jjym2n95bWpHBrrUUgKQlpnnzutt_0csdVpjuj-cNO1UP1jziTxfEqt-rnUmQt2W3MZlsxl4dnNhhHud5TKG8E09GH3s688Muxwmvilw7odvQrAm0Q" 
                alt="Airtel Money Logo" 
                className="w-full h-full object-contain rounded-lg"
              />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white font-sans">Airtel Money</h3>
              <p className="font-mono text-[9px] font-bold text-red-500 tracking-widest uppercase mt-1">
                INSTANT PAYOUT
              </p>
              <p className="text-xs text-slate-400 mt-2 max-w-xs leading-relaxed">
                Real-time liquidity transfers directly into local Airtel Money accounts.
              </p>
            </div>
          </div>

        </div>
      </section>

      {/* Bento Grid Features showcase */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 py-16">
        <div className="grid md:grid-cols-3 gap-6">
          
          <div className="bg-[#0b0f19]/60 hover:bg-[#111625] border border-slate-800 md:col-span-2 p-8 rounded-xl flex flex-col justify-between group">
            <div className="max-w-md text-left">
              <h3 className="text-xl font-bold text-white mb-3">Programmable Payments</h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-6">
                Automate your payroll or supplier payments using smart contracts that trigger on BTC/RWF price points.
              </p>
            </div>
            <div className="bg-[#060913] p-4 rounded-lg border border-slate-800/80 font-mono text-xs text-blue-400 flex items-center gap-4">
              <span className="material-symbols-outlined text-slate-500 text-base">code</span>
              <code>if (btc_rate &gt;= 85000000) {"{"} payout(rwf_vault); {"}"}</code>
            </div>
          </div>

          <div 
            onClick={() => setCurrentTab('login')}
            className="bg-[#0b0f19]/60 hover:bg-[#111625] border border-slate-800 p-8 rounded-xl text-center justify-center flex flex-col items-center group cursor-pointer active:scale-98"
          >
            <span className="material-symbols-outlined text-blue-400 text-4xl mb-4 group-hover:scale-110 transition-transform">
              account_balance
            </span>
            <span className="text-lg font-bold text-white mb-2 font-sans">Institutional Portal</span>
            <p className="text-xs text-slate-400 leading-relaxed">
              Enterprise-grade dashboard tools for banking validators and compliance staff.
            </p>
            <div className="mt-4 flex items-center gap-1.5 text-xs text-blue-400 font-mono group-hover:underline">
              <span>Access Portal</span>
              <span className="material-symbols-outlined text-sm">arrow_forward</span>
            </div>
          </div>

        </div>
      </section>

      {/* Corporate footer */}
      <footer className="bg-[#0c0e13] border-t border-[#434752]/20 w-full py-12 relative z-10">
        <div className="flex flex-col items-center gap-8 px-6 md:px-10 max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between w-full items-center gap-6">
            <div className="flex items-center gap-3">
              <LightningLogo className="h-8 w-8" />
              <span className="text-xl font-bold text-white">FastPay</span>
            </div>
            <div className="flex flex-wrap justify-center gap-6 md:gap-8">
              <a href="#" className="text-xs text-[#c3c6d4] hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="text-xs text-[#c3c6d4] hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="text-xs text-[#c3c6d4] hover:text-[#ffb871] transition-colors flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                Network Operational
              </a>
              <a href="#" className="text-xs text-[#c3c6d4] hover:text-white transition-colors">Developer Docs</a>
            </div>
          </div>
          <p className="text-xs text-[#c3c6d4] text-center md:text-left mt-4">
            © 2026 FastPay Blockchain Gateway. Powered by Stellar. All rights reserved.
          </p>
        </div>
      </footer>

    </div>
  );
}
