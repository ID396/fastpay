import React, { useState, useEffect } from 'react';
import { Tab, Profile } from '../types';
import LanguageSelector, { Language } from './LanguageSelector';
import { getTranslations } from '../locales';
import LightningLogo from './LightningLogo';

interface SettingsProps {
  setCurrentTab: (tab: Tab) => void;
  profileName: string;
  organisationName: string;
  onProfileUpdate: (fullName: string, organisation: string) => void;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
}

export default function Settings({ setCurrentTab, profileName, organisationName, onProfileUpdate, currentLanguage, onLanguageChange, theme, toggleTheme }: SettingsProps) {
  const t = getTranslations(currentLanguage.code);
  const [profile, setProfile] = useState<Profile>({
    fullName: profileName,
    role: "CTO",
    bio: "Architecting the future of real-time cross-border settlements across the East African region.",
    organisationName: organisationName,
    githubUrl: profileName.toLowerCase().includes('rukundo') ? "github.com/theogene-rukundo" : "github.com/kwamemensah",
    linkedinUrl: profileName.toLowerCase().includes('rukundo') ? "linkedin.com/in/theogene-rukundo" : "linkedin.com/in/kwame-mensah",
    notifications: true,
    twoFactorAuth: true,
    emailAlerts: false
  });

  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  // Load backend configurations if present
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await fetch('/api/profile');
        if (res.ok) {
          const data = await res.json();
          // Merge API profile into state
          setProfile(prev => ({
            ...prev,
            fullName: data.fullName || profileName,
            role: data.role || "CTO",
            bio: data.bio || prev.bio,
            organisationName: data.organisationName || organisationName,
            githubUrl: data.githubUrl || prev.githubUrl,
            linkedinUrl: data.linkedinUrl || prev.linkedinUrl,
            notifications: data.notifications !== undefined ? data.notifications : prev.notifications,
            twoFactorAuth: data.twoFactorAuth !== undefined ? data.twoFactorAuth : prev.twoFactorAuth,
            emailAlerts: data.emailAlerts !== undefined ? data.emailAlerts : prev.emailAlerts
          }));
        }
      } catch (err) {
        console.error("Failed to load backend profile configuration", err);
      }
    };
    fetchProfile();
  }, [profileName, organisationName]);

  const handleInputChange = (field: keyof Profile, value: any) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    setSaveStatus('saving');
    
    try {
      // Post to Express backend database
      const res = await fetch('/api/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profile)
      });

      if (res.ok) {
        setTimeout(() => {
          setSaveStatus('saved');
          // Notify main parent state so headers reflect changes instantly
          onProfileUpdate(profile.fullName, profile.organisationName);

          setTimeout(() => {
            setSaveStatus('idle');
          }, 2000);
        }, 1000);
      }
    } catch (err) {
      setSaveStatus('idle');
      alert("Failed to sync structural changes to local database.");
    }
  };

  return (
    <div className="bg-[#111319] text-[#e2e2ea] min-h-screen font-sans flex select-none" id="settings-layout">
      
      {/* Left Sidebar Menu duplication to keep navigation pristine */}
      <aside className="h-screen w-64 fixed left-0 top-0 bg-[#1e1f25] border-r border-[#5E7CE2]/15 flex flex-col py-6 z-40 text-left">
        <div className="px-6 mb-8 cursor-pointer" onClick={() => setCurrentTab('landing')}>
          <div className="flex items-center gap-3 mb-1">
            <LightningLogo className="w-10 h-10" />
            <span className="text-2xl font-black text-[#aec6ff] tracking-tight hover:text-white transition-colors">
              FastPay
            </span>
          </div>
          <p className="font-mono text-[10px] text-[#c3c6d4]/70 font-bold uppercase tracking-wider">
            Customer Dashboard
          </p>
        </div>

        <nav className="flex-1 px-2 space-y-1">
          <button 
            onClick={() => setCurrentTab('dashboard')}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#c3c6d4] hover:bg-[#33353b]/50 transition-all text-left font-mono text-xs font-semibold cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg text-[#8d909d]">dashboard</span>
            <span>{t.dashboard}</span>
          </button>

          <button 
            onClick={() => { setCurrentTab('dashboard'); }}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#c3c6d4] hover:bg-[#33353b]/50 transition-all text-left font-mono text-xs font-semibold cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg text-[#8d909d]">account_balance_wallet</span>
            <span>{t.crossBorderQueue}</span>
          </button>

          <button 
            onClick={() => { setCurrentTab('dashboard'); }}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#c3c6d4] hover:bg-[#33353b]/50 transition-all text-left font-mono text-xs font-semibold cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg text-[#8d909d]">receipt_long</span>
            <span>{t.directPayouts}</span>
          </button>

          <button 
            onClick={() => { setCurrentTab('dashboard'); }}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#c3c6d4] hover:bg-[#33353b]/50 transition-all text-left font-mono text-xs font-semibold cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg text-[#8d909d]">verified_user</span>
            <span>{t.complianceAuditing}</span>
          </button>

          <button 
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-[#173da4] text-white transition-all text-left font-mono text-xs font-semibold"
          >
            <span className="material-symbols-outlined text-lg">settings</span>
            <span>{t.accountSettings}</span>
          </button>
        </nav>

        <div className="mt-auto px-4 space-y-1 py-4 border-t border-[#434752]/20">
          <button 
            onClick={() => setCurrentTab('dashboard')}
            className="w-full flex items-center gap-3 px-4 py-2 text-[#c3c6d4] hover:text-white text-xs font-mono font-medium text-left cursor-pointer"
          >
            <span className="material-symbols-outlined text-base">arrow_back</span>
            <span>{"Cancel"}</span>
          </button>
        </div>
      </aside>

      {/* Main Content Settings columns */}
      <main className="ml-64 flex-grow min-h-screen p-10 bg-[#0c0e13]/60 flex flex-col justify-start">
        <div className="max-w-4xl mx-auto w-full text-left">
          
          <header className="mb-8">
            <h2 className="text-2xl md:text-3xl font-extrabold text-[#aec6ff] font-sans leading-none mb-2">
              {t.accountSettings}
            </h2>
            <p className="text-xs font-sans text-[#c3c6d4]">
              Manage your verified customer profile identity, secure digital wallet keys, and security balance triggers.
            </p>
          </header>

          <div className="space-y-6">
            
            {/* Bento Grid layout style details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Profile Avatar camera card */}
              <section className="glass-card rounded-2xl p-6 flex flex-col items-center justify-center text-center">
                <div className="relative group">
                  <div className="w-32 h-32 rounded-full overflow-hidden mb-4 border-2 border-[#4472ca] p-1 bg-[#1e1f25]">
                    <img 
                      src="https://lh3.googleusercontent.com/aida-public/AB6AXuC5xbce4p9KkyzChVsGtFQPpTNlxgP4KG8G-9eC2KnuY1AWacjLFMJJ9OUkXobggFwXn4Osbnejyf9ccVFjHiszz1TAuOt4-sj_BbXrmV6SSjRYRLMjS8LGMOnPeutzC2SygREQNOSgxWHLLxljoLQvk29mh4nc9nXHWjxPajTGk2K2j4Fk7TBwHk8kiF-XzPoWsfpZ8TPM7cd3uTo0QEJif-nVBiG9KFKNxfzn4D5XFjuKnMk74Sr2_y_HidA2t8dMDGLMAzhLzQb8" 
                      alt="Fintech user representation" 
                      className="w-full h-full object-cover rounded-full"
                    />
                  </div>
                  <button 
                    onClick={() => console.log("Avatar triggers uploads. Simulated selection activated.")}
                    className="absolute bottom-2 right-2 bg-[#aec6ff] p-2 rounded-full text-[#001a43] shadow-lg hover:scale-105 transition-transform cursor-pointer flex items-center justify-center"
                  >
                    <span className="material-symbols-outlined text-sm">photo_camera</span>
                  </button>
                </div>

                <h3 className="text-base font-bold text-white font-sans mt-2 leading-none">
                  {profile.fullName}
                </h3>
                <p className="font-mono text-[10px] text-[#c3c6d4] mt-1.5 uppercase tracking-wider">
                  {profile.role}, {profile.organisationName}
                </p>

                <button 
                  onClick={() => console.log("Photo modifications pending storage.")}
                  className="mt-6 text-[#aec6ff] font-mono text-xs font-bold uppercase hover:underline underline-offset-4 cursor-pointer"
                >
                  Change Photo
                </button>
              </section>

              {/* Personal Information form card */}
              <section className="md:col-span-2 glass-card rounded-2xl p-6 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[#aec6ff] font-sans mb-6 flex items-center gap-2">
                    <span className="material-symbols-outlined text-base block leading-none">person</span>
                    <span>Personal Information</span>
                  </h3>

                  <div className="space-y-4">
                    <div className="space-y-1 text-left">
                      <label className="block text-[10px] font-mono font-semibold text-[#c3c6d4] ml-1 uppercase">Full Name</label>
                      <input 
                        className="w-full bg-[#1e1f25] border border-[#434752]/40 rounded-xl px-4 py-3 text-xs text-white font-sans custom-input" 
                        type="text" 
                        value={profile.fullName}
                        onChange={(e) => handleInputChange('fullName', e.target.value)}
                      />
                    </div>

                    <div className="space-y-1 text-left">
                      <label className="block text-[10px] font-mono font-semibold text-[#c3c6d4] ml-1 uppercase">Bio description</label>
                      <textarea 
                        className="w-full bg-[#1e1f25] border border-[#434752]/40 rounded-xl px-4 py-3 text-xs text-white font-sans resize-none custom-input" 
                        rows={3} 
                        value={profile.bio}
                        onChange={(e) => handleInputChange('bio', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </section>

            </div>

            {/* Grid Row Below: Professional & Socials */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Professional details */}
              <section className="glass-card rounded-2xl p-6">
                <h3 className="text-sm font-bold text-[#aec6ff] font-sans mb-6 flex items-center gap-2">
                  <span className="material-symbols-outlined text-base block leading-none font-semibold">corporate_fare</span>
                  <span>Professional Details</span>
                </h3>

                <div className="space-y-1 text-left">
                  <label className="block text-[10px] font-mono font-semibold text-[#c3c6d4] ml-1 uppercase">Organisation Name</label>
                  <input 
                    className="w-full bg-[#1e1f25] border border-[#434752]/40 rounded-xl px-4 py-3 text-xs text-white font-sans custom-input" 
                    type="text" 
                    value={profile.organisationName}
                    onChange={(e) => handleInputChange('organisationName', e.target.value)}
                  />
                </div>
              </section>

              {/* Social URLs details */}
              <section className="glass-card rounded-2xl p-6">
                <h3 className="text-sm font-bold text-[#aec6ff] font-sans mb-6 flex items-center gap-2">
                  <span className="material-symbols-outlined text-base block leading-none">link</span>
                  <span>Social Connection links</span>
                </h3>

                <div className="space-y-3">
                  <div className="flex gap-2 text-left">
                    <div className="bg-[#1e1f25]/50 px-3.5 rounded-xl border border-[#434752]/30 flex items-center justify-center text-[#c3c6d4]">
                      <span className="material-symbols-outlined text-base">code</span>
                    </div>
                    <input 
                      className="flex-grow bg-[#1e1f25] border border-[#434752]/40 rounded-xl px-4 py-3 text-xs text-white font-mono custom-input" 
                      type="text" 
                      value={profile.githubUrl}
                      onChange={(e) => handleInputChange('githubUrl', e.target.value)}
                    />
                  </div>

                  <div className="flex gap-2 text-left">
                    <div className="bg-[#1e1f25]/50 px-3.5 rounded-xl border border-[#434752]/30 flex items-center justify-center text-[#c3c6d4]">
                      <span className="material-symbols-outlined text-base">hub</span>
                    </div>
                    <input 
                      className="flex-grow bg-[#1e1f25] border border-[#434752]/40 rounded-xl px-4 py-3 text-xs text-white font-mono custom-input" 
                      type="text" 
                      value={profile.linkedinUrl}
                      onChange={(e) => handleInputChange('linkedinUrl', e.target.value)}
                    />
                  </div>
                </div>
              </section>

            </div>

            {/* System Security slider controls */}
            <section className="glass-card rounded-2xl p-6">
              <h3 className="text-sm font-bold text-[#aec6ff] font-sans mb-6 flex items-center gap-2">
                <span className="material-symbols-outlined text-base block leading-none">security</span>
                <span>Security &amp; alert triggers</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Push notification alerts toggle */}
                <div className="flex items-center justify-between p-4 rounded-xl bg-[#1e1f25]/40 border border-[#434752]/10 text-left">
                  <div>
                    <p className="text-xs font-mono font-semibold text-white leading-none">Push Notifications</p>
                    <p className="text-[10px] text-[#c3c6d4] mt-1.5 font-mono">Browser confirmation popups</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={profile.notifications} 
                      onChange={(e) => handleInputChange('notifications', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-[#1e1f25] border border-[#434752]/40 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#4472ca]" />
                  </label>
                </div>

                {/* 2FA validation safety toggle */}
                <div className="flex items-center justify-between p-4 rounded-xl bg-[#1e1f25]/40 border border-[#434752]/10 text-left">
                  <div>
                    <p className="text-xs font-mono font-semibold text-white leading-none">Two-Factor Auth (2FA)</p>
                    <p className="text-[10px] text-[#c3c6d4] mt-1.5 font-mono">Enforce cellular tokens</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={profile.twoFactorAuth} 
                      onChange={(e) => handleInputChange('twoFactorAuth', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-[#1e1f25] border border-[#434752]/40 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#4472ca]" />
                  </label>
                </div>

                {/* Operational log summary reports toggle */}
                <div className="flex items-center justify-between p-4 rounded-xl bg-[#1e1f25]/40 border border-[#434752]/10 text-left">
                  <div>
                    <p className="text-xs font-mono font-semibold text-white leading-none">Daily Email logs</p>
                    <p className="text-[10px] text-[#c3c6d4] mt-1.5 font-mono">Audit sheets delivered at 00:00</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={profile.emailAlerts} 
                      onChange={(e) => handleInputChange('emailAlerts', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-[#1e1f25] border border-[#434752]/40 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#4472ca]" />
                  </label>
                </div>

                {/* Active Light / Dark Theme toggle option */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 rounded-xl bg-[#1e1f25]/40 border border-[#434752]/10 text-left col-span-1 md:col-span-3 gap-3">
                  <div className="flex items-center gap-3">
                    <span className="material-symbols-outlined text-lg text-[#aec6ff]">
                      {theme === 'dark' ? 'dark_mode' : 'light_mode'}
                    </span>
                    <div>
                      <p className="text-xs font-mono font-semibold text-white leading-none">System Theme Toggle</p>
                      <p className="text-[10px] text-[#c3c6d4] mt-1.5 font-mono">
                        Currently running in <strong className="uppercase">{theme} mode</strong>. Switch to configure your visual theme.
                      </p>
                    </div>
                  </div>
                  <button 
                    type="button"
                    onClick={toggleTheme}
                    className="bg-[#4472ca] hover:bg-[#5E7CE2] text-white px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase transition-all duration-200 cursor-pointer active:scale-95 flex items-center gap-1.5 self-stretch sm:self-auto justify-center"
                  >
                    <span className="material-symbols-outlined text-base leading-none">
                      {theme === 'dark' ? 'light_mode' : 'dark_mode'}
                    </span>
                    <span>{theme === 'dark' ? 'Light Theme' : 'Dark Theme'}</span>
                  </button>
                </div>

              </div>
            </section>

            {/* Preferred Portal Language Selection Card */}
            <section className="glass-card rounded-2xl p-6">
              <h3 className="text-sm font-bold text-[#aec6ff] font-sans mb-4 flex items-center gap-2">
                <span className="material-symbols-outlined text-base block leading-none">translate</span>
                <span>Preferred System Language</span>
              </h3>
              <p className="text-xs font-sans text-[#c3c6d4] mb-4">
                Choose from all global languages for your portal clearing hub interface.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                <div>
                  <LanguageSelector 
                    currentLanguage={currentLanguage} 
                    onLanguageChange={onLanguageChange} 
                    variant="dashboard" 
                  />
                </div>
                <div className="text-[11px] font-mono text-[#c3c6d4] leading-relaxed">
                  Active translation language set to <strong className="text-white bg-[#aec6ff]/10 px-2 py-1 rounded border border-[#aec6ff]/20 uppercase">{currentLanguage.name} ({currentLanguage.nativeName})</strong>. Live system triggers will adapt to this.
                </div>
              </div>
            </section>

            {/* Footer Form trigger buttons */}
            <footer className="pt-8 border-t border-[#434752]/15 flex items-center justify-end gap-4">
              <button 
                onClick={() => setCurrentTab('dashboard')}
                className="px-6 py-2.5 border border-[#8d909d]/30 text-xs font-bold text-[#c3c6d4] hover:text-white rounded-xl hover:bg-white/5 transition-all cursor-pointer"
              >
                Cancel / Return
              </button>

              <button 
                onClick={handleSave}
                disabled={saveStatus !== 'idle'}
                className={`px-8 py-2.5 rounded-xl font-bold text-xs transition-all active:scale-95 shadow-xl cursor-pointer ${
                  saveStatus === 'saved' 
                    ? 'bg-green-600 text-white' 
                    : 'bg-[#4472ca] hover:bg-[#5E7CE2] text-white shadow-[#4472ca]/10'
                }`}
              >
                {saveStatus === 'idle' && 'Save Changes'}
                {saveStatus === 'saving' && 'Updating database...'}
                {saveStatus === 'saved' && 'Saved successfully! ✔'}
              </button>
            </footer>

          </div>

        </div>
      </main>

    </div>
  );
}
