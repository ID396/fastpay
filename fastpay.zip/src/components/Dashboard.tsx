import React, { useState, useEffect } from 'react';
import { Tab, Transaction, Payout } from '../types';
import LanguageSelector, { Language } from './LanguageSelector';
import { getTranslations } from '../locales';
import LightningLogo from './LightningLogo';

interface DashboardProps {
  currentTab: Tab;
  setCurrentTab: (tab: Tab) => void;
  onLogout: () => void;
  profileName: string;
  organisationName: string;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
}

export default function Dashboard({ currentTab, setCurrentTab, onLogout, profileName, organisationName, currentLanguage, onLanguageChange, theme, toggleTheme }: DashboardProps) {
  const t = getTranslations(currentLanguage.code);
  // In-memory states synchronized from API
  const [reserves, setReserves] = useState(52000000);
  const [incomingBtc, setIncomingBtc] = useState(0.4502);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [corridors, setCorridors] = useState<any[]>([]);
  const [tickets, setTickets] = useState<any[]>([]);

  // Customer specific wallet balances
  const [btcWallet, setBtcWallet] = useState(0.4502);
  const [rwfWallet, setRwfWallet] = useState(12850000);
  const [usdWallet, setUsdWallet] = useState(9450);
  
  // Tab controller for dynamic views in the dashboard
  const [dashboardSubTab, setDashboardSubTab] = useState<'transactions' | 'corridors' | 'tickets'>('transactions');
  
  // Interactive UI triggers
  const [newPaymentOpen, setNewPaymentOpen] = useState(false);
  const [mobilePayoutOpen, setMobilePayoutOpen] = useState(false);
  
  // Form values
  const [newOrigin, setNewOrigin] = useState('Standard Bank (SA)');
  const [newBtc, setNewBtc] = useState('0.05');
  const [payoutPhone, setPayoutPhone] = useState('+250 788 ');
  const [payoutNetwork, setPayoutNetwork] = useState<'MTN MoMo' | 'Airtel Money'>('MTN MoMo');
  const [payoutAmount, setPayoutAmount] = useState('15000');
  
  // Multi-sign workflow signatures count
  const [txSignatures, setTxSignatures] = useState({ tx8829: 2, tx9011: 1 });
  
  // Quick dropdown triggers
  const [emailOpen, setEmailOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  
  // Live flutuation bar heights for mini chart
  const [chartHeights, setChartHeights] = useState([47, 43, 78, 79, 41, 79]);
  
  // Fetch API entries
  const fetchDashboardData = async () => {
    try {
      const res = await fetch('/api/dashboard');
      if (res.ok) {
        const data = await res.json();
        setReserves(data.reserves);
        setIncomingBtc(data.incomingBtc24h);
        setTransactions(data.transactions);
        setPayouts(data.payouts);
        setCorridors(data.corridors || []);
        setTickets(data.tickets || []);
        if (data.customerBalances) {
          setBtcWallet(data.customerBalances.btc);
          setRwfWallet(data.customerBalances.rwf);
          setUsdWallet(data.customerBalances.usd);
        }
      }
    } catch (err) {
      console.error("Dashboard synchronization error", err);
    }
  };

  useEffect(() => {
    fetchDashboardData();
    // Fetch data every 5 seconds for live simulation
    const dbInterval = setInterval(fetchDashboardData, 5000);

    // Dynamic mini-chart variance
    const chartInterval = setInterval(() => {
      setChartHeights(prev => prev.map(() => Math.floor(Math.random() * 50) + 30));
    }, 3000);

    return () => {
      clearInterval(dbInterval);
      clearInterval(chartInterval);
    };
  }, []);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage('');
    }, 4000);
  };

  // Swap desk variables
  const [swapFromAsset, setSwapFromAsset] = useState<'BTC' | 'RWF' | 'USD'>('BTC');
  const [swapToAsset, setSwapToAsset] = useState<'BTC' | 'RWF' | 'USD'>('RWF');
  const [swapAmount, setSwapAmount] = useState<string>('0.01');
  const [swapLoading, setSwapLoading] = useState(false);

  // Deposit desk variables
  const [depAsset, setDepAsset] = useState<'BTC' | 'RWF' | 'USD'>('RWF');
  const [depAmount, setDepAmount] = useState<string>('150000');
  const [depLoading, setDepLoading] = useState(false);

  const handleExecuteSwap = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(swapAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      triggerToast("Swap amount must be greater than zero.");
      return;
    }
    setSwapLoading(true);
    try {
      const res = await fetch('/api/customer/convert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fromAsset: swapFromAsset,
          toAsset: swapToAsset,
          amount: amountNum
        })
      });
      const data = await res.json();
      if (res.ok) {
        triggerToast(`Successfully converted ${amountNum} ${swapFromAsset} ! Received ${data.received.toLocaleString(undefined, {maximumFractionDigits: swapToAsset === 'BTC' ? 4 : 2})} ${swapToAsset}`);
        fetchDashboardData();
      } else {
        triggerToast(data.error || "Swap failed.");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error communicating with swap module.");
    } finally {
      setSwapLoading(false);
    }
  };

  const handleExecuteDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(depAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      triggerToast("Deposit amount must be greater than zero.");
      return;
    }
    setDepLoading(true);
    try {
      const res = await fetch('/api/customer/deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          asset: depAsset,
          amount: amountNum
        })
      });
      const data = await res.json();
      if (res.ok) {
        triggerToast(`Successfully deposited ${amountNum.toLocaleString(undefined, {maximumFractionDigits: depAsset === 'BTC' ? 4 : 2})} ${depAsset} in your customer profile!`);
        fetchDashboardData();
      } else {
        triggerToast(data.error || "Deposit failed.");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error communicating with deposit module.");
    } finally {
      setDepLoading(false);
    }
  };

  // Release queue item
  const handleRelease = async (id: string, rwfAmt: number) => {
    try {
      const res = await fetch('/api/transactions/release', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      if (res.ok) {
        triggerToast(`Successfully released STLR transaction. ${rwfAmt.toLocaleString()} RWF is now settling in domestic standard corridors.`);
        fetchDashboardData();
      } else {
        const err = await res.json();
        triggerToast(`Release failed: ${err.error}`);
      }
    } catch (err) {
      triggerToast("Failed to dispatch release trigger to local rails.");
    }
  };

  // Submit Incoming BTC Payment
  const handleNewPaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBtc || isNaN(parseFloat(newBtc)) || parseFloat(newBtc) <= 0) {
      triggerToast("Please enter a valid cryptographic numeric value.");
      return;
    }

    try {
      const res = await fetch('/api/transactions/new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          originHub: newOrigin,
          assetValue: parseFloat(newBtc)
        })
      });
      if (res.ok) {
        setNewPaymentOpen(false);
        triggerToast(`Successfully recorded ${newBtc} BTC incoming vault deposit on Stellar.`);
        fetchDashboardData();
      }
    } catch (err) {
      triggerToast("Failed to record local payload.");
    }
  };

  // Submit Mobile Payout
  const handleMobilePayoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payoutPhone || payoutPhone.length < 8) {
      triggerToast("Please input an active cellular SIM target number.");
      return;
    }
    if (!payoutAmount || isNaN(parseInt(payoutAmount)) || parseInt(payoutAmount) <= 0) {
      triggerToast("Please input a valid numeric payout currency amount.");
      return;
    }

    try {
      const res = await fetch('/api/payouts/new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: payoutPhone,
          network: payoutNetwork,
          amount: parseInt(payoutAmount)
        })
      });
      
      const data = await res.json();
      if (res.ok) {
        setMobilePayoutOpen(false);
        triggerToast(`Successfully dispatched ${parseInt(payoutAmount).toLocaleString()} RWF payout request to ${payoutNetwork}. Status: Pending.`);
        fetchDashboardData();
      } else {
        triggerToast(`Payout rejection: ${data.error}`);
      }
    } catch (err) {
      triggerToast("Payout validation returned structural failures.");
    }
  };

  return (
    <div className="bg-[#111319] text-[#e2e2ea] min-h-screen font-sans flex select-none" id="dashboard-layout">
      
      {/* Toast Alert Drawer */}
      {toastMessage && (
        <div className="fixed top-20 right-8 z-55 max-w-sm bg-[#16223B] border border-[#aec6ff]/30 rounded-xl p-4 shadow-2xl flex items-start gap-3 transition-transform animate-bounce">
          <span className="material-symbols-outlined text-[#aec6ff]">info</span>
          <p className="text-xs text-[#e2e2ea] font-sans leading-relaxed">{toastMessage}</p>
        </div>
      )}

      {/* Left Sidebar Menu */}
      <aside className="h-screen w-64 fixed left-0 top-0 bg-[#1e1f25] border-r border-[#5E7CE2]/15 flex flex-col py-6 z-40 text-left">
        
        {/* Logo and Head Title */}
        <div className="px-6 mb-8 cursor-pointer" onClick={() => setCurrentTab('landing')}>
          <div className="flex items-center gap-3 mb-1">
            <LightningLogo className="w-10 h-10" />
            <span className="text-2xl font-black text-[#aec6ff] tracking-tight hover:text-white transition-colors">
              FastPay
            </span>
          </div>
          <p className="font-mono text-[10px] text-[#c3c6d4]/70 font-bold uppercase tracking-wider">
            Customer Dashboard
          </p>
        </div>

        {/* Sidebar Nav links */}
        <nav className="flex-1 px-2 space-y-1 text-left">
          <button 
            onClick={() => setDashboardSubTab('transactions')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-left font-mono text-xs font-semibold cursor-pointer ${
              dashboardSubTab === 'transactions' ? 'bg-[#173da4] text-white' : 'text-[#c3c6d4] hover:bg-[#33353b]/50'
            }`}
          >
            <span className="material-symbols-outlined text-lg">dashboard</span>
            <span>{t.dashboard}</span>
          </button>

          <button 
            onClick={() => {
              setDashboardSubTab('corridors');
              triggerToast("Inspecting active Stellar-RWF regional corridors.");
            }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-left font-mono text-xs font-semibold cursor-pointer ${
              dashboardSubTab === 'corridors' ? 'bg-[#173da4] text-white' : 'text-[#c3c6d4] hover:bg-[#33353b]/50'
            }`}
          >
            <span className="material-symbols-outlined text-lg">domain</span>
            <span>Corridor Registry</span>
          </button>

          <button 
            onClick={() => {
              setDashboardSubTab('tickets');
              triggerToast("Inspecting emergency technical incident logs.");
            }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-left font-mono text-xs font-semibold cursor-pointer ${
              dashboardSubTab === 'tickets' ? 'bg-[#173da4] text-white' : 'text-[#c3c6d4] hover:bg-[#33353b]/50'
            }`}
          >
            <span className="material-symbols-outlined text-lg">support_agent</span>
            <span>Support Logs</span>
          </button>

          <div className="h-px bg-[#434752]/20 my-2 mx-4" />

          <button 
            onClick={() => triggerToast("Ledger settlements history is fully synced with Stellar Anchor.")}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#c3c6d4] hover:bg-[#33353b]/50 transition-all text-left font-mono text-xs font-semibold cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg text-[#8d909d]">account_balance_wallet</span>
            <span>{t.crossBorderQueue}</span>
          </button>

          <button 
            onClick={() => triggerToast("Operational cold-reserves account status: Active & Audited.")}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#c3c6d4] hover:bg-[#33353b]/50 transition-all text-left font-mono text-xs font-semibold cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg text-[#8d909d]">receipt_long</span>
            <span>{t.directPayouts}</span>
          </button>

          <button 
            onClick={() => triggerToast("AML sanction status: Verified and Compliant with BNR requirements.")}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#c3c6d4] hover:bg-[#33353b]/50 transition-all text-left font-mono text-xs font-semibold cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg text-[#8d909d]">verified_user</span>
            <span>{t.complianceAuditing}</span>
          </button>

          <button 
            onClick={() => setCurrentTab('settings')}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#c3c6d4] hover:bg-[#33353b]/50 transition-all text-left font-mono text-xs font-semibold cursor-pointer"
          >
            <span className="material-symbols-outlined text-lg text-[#8d909d]">settings</span>
            <span>{t.accountSettings}</span>
          </button>
        </nav>

        {/* Action dispatches at bottom sidebar */}
        <div className="mt-auto px-4 space-y-4">
          <button 
            onClick={() => setNewPaymentOpen(true)}
            className="w-full bg-[#4472ca] hover:bg-[#5E7CE2] text-white py-3.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer shadow-lg shadow-[#4472ca]/10"
          >
            <span className="material-symbols-outlined text-sm">add</span>
            {t.addIncomingBtn}
          </button>
          
          <button 
            onClick={() => setMobilePayoutOpen(true)}
            className="w-full bg-[#5E7CE2]/10 hover:bg-[#5E7CE2]/20 text-[#5E7CE2] py-3.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
          >
            <span className="material-symbols-outlined text-sm">smartphone</span>
            {t.payoutToMobileBtn}
          </button>

          <div className="pt-4 border-t border-[#434752]/20 space-y-1">
            <button 
              onClick={() => triggerToast("Direct emergency helpline: compliance@fastpay.rw")}
              className="w-full flex items-center gap-3 px-4 py-2 text-[#c3c6d4] hover:text-white text-xs font-mono font-medium text-left cursor-pointer"
            >
              <span className="material-symbols-outlined text-base">help</span>
              <span>{t.emergencySupport}</span>
            </button>
            <button 
              onClick={onLogout}
              className="w-full flex items-center gap-3 px-4 py-2 text-[#c3c6d4] hover:text-[#ffb4ab] text-xs font-mono font-medium text-left cursor-pointer"
            >
              <span className="material-symbols-outlined text-base">logout</span>
              <span>{t.signOut}</span>
            </button>
          </div>
        </div>

      </aside>

      {/* Main Container Area */}
      <main className="ml-64 flex-grow min-h-screen flex flex-col">
        
        {/* Top Header Panel */}
        <header className="h-16 flex items-center justify-between px-10 bg-[#111319]/80 backdrop-blur-md border-b border-[#5E7CE2]/10 sticky top-0 z-30 text-left">
          
          <div className="flex items-center gap-4">
            <span className="text-xl font-extrabold text-[#aec6ff] font-sans">
              {organisationName}
            </span>
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-[#ffb871]/10 border border-[#ffb871]/20">
              <span className="w-2 h-2 rounded-full bg-[#ffb871] animate-pulse" />
              <span className="font-mono text-[9px] font-bold text-[#ffb871] uppercase tracking-wider">
                {t.systemOperational}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <LanguageSelector 
              currentLanguage={currentLanguage} 
              onLanguageChange={onLanguageChange} 
              variant="dashboard" 
            />

            <button 
              onClick={toggleTheme}
              className="material-symbols-outlined text-[#c3c6d4] hover:text-white cursor-pointer transition-colors text-xl p-1.5 rounded-lg bg-[#33353b]/30 hover:bg-[#33353b]/60 flex items-center justify-center border border-[#8d909d]/10"
              title={theme === 'dark' ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {theme === 'dark' ? 'light_mode' : 'dark_mode'}
            </button>

            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-[#aec6ff]/10 border border-[#aec6ff]/20">
              <span className="material-symbols-outlined text-xs text-[#aec6ff] leading-none">
                notifications_active
              </span>
              <span className="font-mono text-[9px] font-bold text-[#aec6ff] uppercase tracking-wider">
                SMS Alerts Triggered
              </span>
            </div>

            <div className="h-8 w-px bg-[#434752]/30" />

            {/* Profile Avatar Trigger block */}
            <div 
              onClick={() => setCurrentTab('settings')}
              className="flex items-center gap-4 cursor-pointer group"
              id="header-profile-box"
            >
              <div className="text-right hidden sm:block">
                <p className="font-sans text-xs font-bold text-white leading-none mb-1 group-hover:text-[#aec6ff] transition-colors">
                  {profileName}
                </p>
                <p className="text-[9px] font-mono text-[#c3c6d4] uppercase tracking-wider leading-none">
                  {organisationName} (validator)
                </p>
              </div>
              <div className="relative">
                <div className="w-10 h-10 rounded-full border-2 border-[#aec6ff]/20 p-0.5 overflow-hidden transition-all group-hover:border-[#aec6ff]">
                  <img 
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuC5xbce4p9KkyzChVsGtFQPpTNlxgP4KG8G-9eC2KnuY1AWacjLFMJJ9OUkXobggFwXn4Osbnejyf9ccVFjHiszz1TAuOt4-sj_BbXrmV6SSjRYRLMjS8LGMOnPeutzC2SygREQNOSgxWHLLxljoLQvk29mh4nc9nXHWjxPajTGk2K2j4Fk7TBwHk8kiF-XzPoWsfpZ8TPM7cd3uTo0QEJif-nVBiG9KFKNxfzn4D5XFjuKnMk74Sr2_y_HidA2t8dMDGLMAzhLzQb8" 
                    alt="Theogene Rukundo avatar" 
                    className="w-full h-full object-cover rounded-full bg-[#1e1f25]"
                  />
                </div>
                <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-[#111319] rounded-full" />
              </div>
            </div>
          </div>

        </header>

        {/* Dynamic canvas areas */}
        <div className="flex-grow p-10 text-left">
          
          {/* Top Grid Summaries Widget blocks */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8" id="dashboard-metric-cards">
            
            {/* BTC Wallet metric */}
            <div className="glass-card p-6 rounded-2xl flex flex-col justify-between border-[#aec6ff]/10">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs font-mono font-medium text-[#c3c6d4] uppercase tracking-wider leading-none mb-2">
                    Bitcoin Balance (BTC)
                  </p>
                  <h2 className="text-2xl font-black text-[#aec6ff] tracking-tight">
                    {btcWallet.toFixed(4)} BTC
                  </h2>
                </div>
                <div className="p-2 bg-[#aec6ff]/10 rounded-xl text-[#aec6ff]">
                  <span className="material-symbols-outlined text-lg leading-none block">currency_bitcoin</span>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold text-[#ffb871] bg-[#ffb871]/10 px-2 py-0.5 rounded-full">
                  ~ ${(btcWallet * 65000).toLocaleString()} USD Value
                </span>
              </div>
            </div>

            {/* RWF Wallet metric */}
            <div className="glass-card p-6 rounded-2xl flex flex-col justify-between border-[#5E7CE2]/10">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs font-mono font-medium text-[#c3c6d4] uppercase tracking-wider leading-none mb-2">
                    Rwandan Franc Balance (RWF)
                  </p>
                  <h2 className="text-2xl font-black text-white tracking-tight">
                    {rwfWallet.toLocaleString()} RWF
                  </h2>
                </div>
                <div className="p-2 bg-[#5E7CE2]/10 rounded-xl text-[#5E7CE2]">
                  <span className="material-symbols-outlined text-lg leading-none block">payments</span>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-3">
                <div className="flex-grow bg-[#434752]/20 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-[#5E7CE2] h-full" style={{ width: '80%' }} />
                </div>
                <span className="text-[10px] font-mono font-bold text-[#c3c6d4]">Local FastPay Cash</span>
              </div>
            </div>

            {/* USD Wallet metric */}
            <div className="glass-card p-6 rounded-2xl flex flex-col justify-between border-green-500/10 bg-green-500/5">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs font-mono font-medium text-[#c3c6d4] uppercase tracking-wider leading-none mb-2">
                    US Dollar Balance (USD)
                  </p>
                  <h2 className="text-2xl font-black text-emerald-400 tracking-tight">
                    ${usdWallet.toLocaleString(undefined, { minimumFractionDigits: 2 })} USD
                  </h2>
                </div>
                <div className="p-2 bg-green-500/10 rounded-xl text-green-400">
                  <span className="material-symbols-outlined text-lg leading-none block">account_balance_wallet</span>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded-full">
                  International Balance
                </span>
              </div>
            </div>

          </div>

          {/* Sub Tab Switcher */}
          <div className="flex border-b border-[#434752]/20 mb-6 gap-2">
            <button
              onClick={() => setDashboardSubTab('transactions')}
              className={`pb-3 px-4 font-sans text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer ${
                dashboardSubTab === 'transactions'
                  ? 'border-b-2 border-[#5E7CE2] text-white font-bold'
                  : 'text-[#c3c6d4] hover:text-white'
              }`}
            >
              <span className="material-symbols-outlined text-sm">history</span>
              My Conversions Ledger
            </button>

            <button
              onClick={() => {
                setDashboardSubTab('corridors');
              }}
              className={`pb-3 px-4 font-sans text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer ${
                dashboardSubTab === 'corridors'
                  ? 'border-b-2 border-green-500 text-green-400 font-bold'
                  : 'text-[#c3c6d4] hover:text-white'
              }`}
            >
              <span className="material-symbols-outlined text-sm">swap_calls</span>
              Conversion & Swap Desk
            </button>

            <button
              onClick={() => {
                setDashboardSubTab('tickets');
              }}
              className={`pb-3 px-4 font-sans text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer ${
                dashboardSubTab === 'tickets'
                  ? 'border-b-2 border-blue-500 text-blue-400 font-bold'
                  : 'text-[#c3c6d4] hover:text-white'
              }`}
            >
              <span className="material-symbols-outlined text-sm">payments</span>
              Direct Deposit Desk
            </button>
          </div>

          {dashboardSubTab === 'transactions' && (
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
              
              {/* Cross-border Ledger Queue */}
              <div className="xl:col-span-8 glass-card rounded-2xl overflow-hidden border-[#434752]/20 flex flex-col justify-between">
                <div>
                  
                  {/* Table Header actions */}
                  <div className="px-6 py-4 border-b border-[#434752]/20 flex justify-between items-center bg-[#1e1f25]/40">
                    <h3 className="text-sm font-bold text-white font-sans uppercase tracking-wider">
                      {t.crossBorderQueue}
                    </h3>

                    <div className="flex items-center gap-4 text-xs font-mono font-semibold">
                      
                      {/* Simulated dropdown */}
                      <div className="relative">
                        <button 
                          onClick={() => setEmailOpen(!emailOpen)}
                          className="flex items-center gap-1.5 text-[#c3c6d4] hover:text-[#aec6ff] transition-colors cursor-pointer"
                          id="email-trigger"
                        >
                          <span className="material-symbols-outlined text-sm">mail</span>
                          <span>{t.emailHistory}</span>
                          <span className="material-symbols-outlined text-[10px]">arrow_drop_down</span>
                        </button>

                        {emailOpen && (
                          <div className="absolute right-0 mt-2 w-64 glass-card rounded-xl shadow-2xl z-50 overflow-hidden border border-[#5E7CE2]/30 text-left">
                            <div className="flex flex-col py-1 bg-[#1e1f25]">
                              <button 
                                onClick={() => {
                                  setEmailOpen(false);
                                  triggerToast("Daily validation summary sent to " + profileName.toLowerCase().replace(' ', '.') + "@bk.rw");
                                }}
                                className="px-4 py-2.5 text-left text-xs text-[#c3c6d4] hover:bg-[#aec6ff]/10 hover:text-[#aec6ff] transition-colors flex items-center gap-2.5 cursor-pointer"
                              >
                                <span className="material-symbols-outlined text-sm">summarize</span>
                                Send Daily Summary
                              </button>
                              <button 
                                onClick={() => {
                                  setEmailOpen(false);
                                  triggerToast("Ledger CSV list compiling. Injected into email queue.");
                                }}
                                className="px-4 py-2.5 text-left text-xs text-[#c3c6d4] hover:bg-[#aec6ff]/10 hover:text-[#aec6ff] transition-colors flex items-center gap-2.5 cursor-pointer"
                              >
                                <span className="material-symbols-outlined text-sm">csv</span>
                                Email CSV Export
                              </button>
                              <div className="h-px bg-[#434752]/20 mx-4 my-1" />
                              <button 
                                onClick={() => {
                                  setEmailOpen(false);
                                  triggerToast("Recurring reports configured on current treasury thresholds.");
                                }}
                                className="px-4 py-2.5 text-left text-xs text-[#c3c6d4] hover:bg-[#aec6ff]/10 hover:text-[#aec6ff] transition-colors flex items-center gap-2.5 cursor-pointer"
                              >
                                <span className="material-symbols-outlined text-sm">schedule_send</span>
                                Recurring Reports
                              </button>
                            </div>
                          </div>
                        )}
                      </div>

                      <button 
                        onClick={() => triggerToast("Displaying all 3 linked accounts. Active sync completed.")}
                        className="text-[#aec6ff] hover:underline cursor-pointer"
                      >
                        {t.viewAll}
                      </button>
                    </div>
                  </div>

                  {/* Main Queue table content */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-left font-sans">
                      <thead className="bg-[#1e1f25]/50 font-mono text-[9px] font-bold text-[#c3c6d4] uppercase tracking-wider">
                        <tr>
                          <th className="px-6 py-4">{t.tableTxId}</th>
                          <th className="px-6 py-4">{t.tableOrigin}</th>
                          <th className="px-6 py-4">{t.tableAssetValue}</th>
                          <th className="px-6 py-4">{t.tableAmount}</th>
                          <th className="px-6 py-4">{t.tableStatus}</th>
                          <th className="px-6 py-4 text-right">{t.tableAction}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#434752]/10 text-xs">
                        {transactions.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="px-6 py-10 text-center text-[#c3c6d4]">
                              No pending validation ledger dispatches recorded.
                            </td>
                          </tr>
                        ) : (
                          transactions.map((tx) => (
                            <tr key={tx.id} className="hover:bg-[#33353b]/20 transition-colors">
                              <td className="px-6 py-4 font-mono font-medium text-white">{tx.id}</td>
                              <td className="px-6 py-4 text-[#c3c6d4]">{tx.originHub}</td>
                              <td className="px-6 py-4 font-mono font-medium text-[#aec6ff]">{tx.assetValue} BTC</td>
                              <td className="px-6 py-4 font-mono font-medium text-white">{tx.rwfAmount.toLocaleString()} RWF</td>
                              <td className="px-6 py-4">
                                <span className={`px-2.5 py-1 rounded text-[10px] font-mono font-bold ${
                                  tx.status === 'Wait Fiat' 
                                    ? 'bg-[#ffb871]/10 text-[#ffb871]' 
                                    : 'bg-green-500/10 text-green-400'
                                }`}>
                                  {tx.status === 'Wait Fiat' ? 'Wait Fiat' : 'Released'}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-right">
                                {tx.status === 'Wait Fiat' ? (
                                  <button 
                                    onClick={() => handleRelease(tx.id, tx.rwfAmount)}
                                    className="bg-[#5E7CE2]/10 text-[#5E7CE2] hover:bg-[#5E7CE2] hover:text-white px-3 py-1 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer"
                                  >
                                    {t.releaseBtn}
                                  </button>
                                ) : (
                                  <span className="material-symbols-outlined text-green-500 text-base leading-none">
                                    check_circle
                                  </span>
                                )}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                </div>
              </div>

              {/* Right Side Control Panel Widgets */}
              <div className="xl:col-span-4 space-y-6">
                
                {/* BTC / RWF Ticker Widget info */}
                <div className="glass-card p-6 rounded-2xl">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-bold text-white font-sans uppercase tracking-wider">
                      BTC / RWF Index
                    </h3>
                    <button 
                      onClick={() => {
                        triggerToast("Ticker index re-synchronized with index indices.");
                        setChartHeights(prev => prev.map(() => Math.floor(Math.random() * 50) + 30));
                      }}
                      className="material-symbols-outlined text-[#c3c6d4] hover:text-[#aec6ff] text-base cursor-pointer p-1 rounded hover:bg-[#1e1f25]"
                    >
                      refresh
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <div className="flex items-center gap-2">
                        <img 
                          src="https://lh3.googleusercontent.com/aida-public/AB6AXuC_DzaSJfdd6kH2DlUHmPtS5nwoy7gJ8PoWj9dT6CWxGDvIDtP7iV7nZv4AWKyABFhXvfLeDx0P94aZR0ZVKKWDQ5PGPo7rpNWtWRp8xnhgH2nnuhQNAeASUKwsD__b65CVz_BuyjBKs9DArXte338XrxQpASFnoNA6t32NUwMl6xE2fz3tN8Ku3OxeEoegS6Mu9lH23DnMREuKKzIPU4buYnIRXGQVTT0LcI7Dsx0OVDboHfYLbEuTSdaiugmUv1X0bLDYmS2QQ0ls" 
                          alt="Rwanda Flag" 
                          className="w-5 h-3.5 object-cover rounded-sm border border-[#434752]/20"
                        />
                        <span className="text-[#c3c6d4]">Global Average</span>
                      </div>
                      <span className="text-[#aec6ff] font-mono">1 BTC ≈ 67,670,000 RWF</span>
                    </div>

                    {/* Manual visual Mini SVG price charts fluctuate slightly */}
                    <div className="p-4 bg-[#0c0e13]/60 rounded-xl border border-[#5E7CE2]/10">
                      <div className="h-16 w-full flex items-end gap-1" id="live-conversion-chart">
                        {chartHeights.map((h, idx) => (
                          <div 
                            key={idx}
                            style={{ height: `${h}%` }}
                            className={`flex-1 rounded-sm transition-all duration-700 ${
                              idx === chartHeights.length - 1 ? 'bg-[#aec6ff]' : 'bg-[#5E7CE2]/40'
                            }`}
                          />
                        ))}
                      </div>
                      <p className="text-center font-mono text-[9px] text-[#c3c6d4]/60 uppercase tracking-wider mt-2.5 font-bold">
                        24h Price Index Trend (Live variance)
                      </p>
                    </div>
                  </div>

                </div>

                {/* On Duty Validators list */}
                <div className="glass-card p-6 rounded-2xl">
                  <h3 className="text-sm font-bold text-white mb-4 uppercase tracking-wider">
                    On-duty Officers
                  </h3>

                  <div className="space-y-4">
                    
                    {/* Officer Sarah */}
                    <div className="flex items-center gap-4 text-left">
                      <div className="w-10 h-10 rounded-full bg-[#173da4]/20 border border-[#173da4]/40 flex items-center justify-center text-[#9eb2ff]">
                        <span className="material-symbols-outlined text-lg">admin_panel_settings</span>
                      </div>
                      <div className="flex-grow">
                        <p className="font-sans text-xs font-bold text-white leading-none">Sarah Kamau</p>
                        <p className="text-[10px] font-mono text-[#ffb871] mt-1 leading-none">Compliance Officer</p>
                      </div>
                      <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    </div>

                    {/* Officer Jean Pierre */}
                    <div className="flex items-center gap-4 text-left">
                      <div className="w-10 h-10 rounded-full bg-[#1e1f25] border border-[#434752]/30 flex items-center justify-center text-[#c3c6d4]">
                        <span className="material-symbols-outlined text-lg">payments</span>
                      </div>
                      <div className="flex-grow">
                        <p className="font-sans text-xs font-bold text-white leading-none">Jean Pierre</p>
                        <p className="text-[10px] font-mono text-[#c3c6d4] mt-1 leading-none">Treasurer</p>
                      </div>
                      <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    </div>

                    {/* Root Validation coordinator */}
                    <div className="flex items-center gap-4 text-left">
                      <div className="w-10 h-10 rounded-full bg-[#aec6ff]/10 border border-[#aec6ff]/20 flex items-center justify-center text-[#aec6ff]">
                        <span className="material-symbols-outlined text-lg">verified</span>
                      </div>
                      <div className="flex-grow">
                        <p className="font-sans text-xs font-bold text-white leading-none">System Root</p>
                        <p className="text-[10px] font-mono text-[#aec6ff] mt-1 leading-none">Admin Authority</p>
                      </div>
                      <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    </div>

                  </div>
                </div>

                {/* Mobile Mobile Payouts Status showcase */}
                <div className="glass-card p-6 rounded-2xl">
                  <h3 className="text-sm font-bold text-white mb-4 uppercase tracking-wider">
                    Mobile Payout Status
                  </h3>

                  <div className="space-y-3 font-sans text-xs">
                    {payouts.length === 0 ? (
                      <p className="text-center text-[#c3c6d4] py-4">No mobile payouts recorded</p>
                    ) : (
                      payouts.map((po, idx) => {
                        const isSuccess = po.status === 'Success';
                        return (
                          <div key={idx} className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                              po.network === 'MTN MoMo' ? 'bg-[#ffcc00]' : 'bg-[#e31937]'
                            }`}>
                              <span className="material-symbols-outlined text-[14px] text-black font-semibold">
                                smartphone
                              </span>
                            </div>
                            
                            <div className="flex-grow text-left">
                              <p className="font-mono text-white text-[11px] leading-none mb-1">{po.phone}</p>
                              <p className="text-[9px] font-mono text-[#c3c6d4] leading-none">
                                {po.network} • {po.amount.toLocaleString()} RWF
                              </p>
                            </div>

                            <span className={`text-[10px] font-mono font-bold uppercase ${
                              isSuccess ? 'text-green-500' : 'text-[#ffb871] animate-pulse'
                            }`}>
                              {po.status}
                            </span>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

              </div>

            </div>
          )}

          {dashboardSubTab === 'corridors' && (
            <div className="space-y-6">
              <div className="glass-card p-6 md:p-8 rounded-2xl border border-green-500/15">
                <header className="mb-6 flex justify-between items-center flex-wrap gap-4">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2 text-left">
                      <span className="material-symbols-outlined text-green-400">swap_calls</span>
                      Bitcoin & Fiat Conversions Desk
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 text-left">Swap your Bitcoin into local RWF/USD, or purchase Bitcoin using your local fiat balances instantly.</p>
                  </div>
                  <div className="flex items-center gap-2 bg-[#1e1f25] border border-green-950/40 rounded-lg py-1.5 px-3 text-[10px] font-mono font-semibold text-green-400 animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-green-400" />
                    Direct Exchange Online
                  </div>
                </header>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-left">
                  
                  {/* Left Controls Card */}
                  <form onSubmit={handleExecuteSwap} className="lg:col-span-7 space-y-6 bg-[#16171d]/80 p-6 rounded-2xl border border-slate-800">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      {/* From asset selector */}
                      <div className="space-y-2">
                        <label className="text-xs font-mono font-bold text-slate-400">Convert From (Source)</label>
                        <select
                          value={swapFromAsset}
                          onChange={(e) => {
                            const val = e.target.value as 'BTC' | 'RWF' | 'USD';
                            setSwapFromAsset(val);
                            if (val === swapToAsset) {
                              setSwapToAsset(val === 'BTC' ? 'RWF' : 'BTC');
                            }
                          }}
                          className="w-full bg-[#1c1d24] border border-[#434752]/40 rounded-xl py-3 px-4 text-xs text-white cursor-pointer font-bold focus:border-[#aec6ff]"
                        >
                          <option value="BTC">Bitcoin (BTC)</option>
                          <option value="RWF">Rwandan Francs (RWF)</option>
                          <option value="USD">US Dollars (USD)</option>
                        </select>
                        <p className="text-[10px] text-slate-400 font-mono">
                          Current: {swapFromAsset === 'BTC' ? `${btcWallet.toFixed(4)} BTC` : swapFromAsset === 'RWF' ? `${rwfWallet.toLocaleString()} RWF` : `$${usdWallet.toLocaleString()} USD`} available
                        </p>
                      </div>

                      {/* To asset selector */}
                      <div className="space-y-2">
                        <label className="text-xs font-mono font-bold text-slate-400">Receive Asset (Destination)</label>
                        <select
                          value={swapToAsset}
                          onChange={(e) => {
                            const val = e.target.value as 'BTC' | 'RWF' | 'USD';
                            setSwapToAsset(val);
                            if (val === swapFromAsset) {
                              setSwapFromAsset(val === 'BTC' ? 'RWF' : 'BTC');
                            }
                          }}
                          className="w-full bg-[#1c1d24] border border-[#434752]/40 rounded-xl py-3 px-4 text-xs text-white cursor-pointer font-bold focus:border-green-500"
                        >
                          <option value="BTC">Bitcoin (BTC)</option>
                          <option value="RWF">Rwandan Francs (RWF)</option>
                          <option value="USD">US Dollars (USD)</option>
                        </select>
                        <p className="text-[10px] text-slate-400 font-mono">
                          Current: {swapToAsset === 'BTC' ? `${btcWallet.toFixed(4)} BTC` : swapToAsset === 'RWF' ? `${rwfWallet.toLocaleString()} RWF` : `$${usdWallet.toLocaleString()} USD`} available
                        </p>
                      </div>

                    </div>

                    {/* Swap Amount */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-xs font-mono font-bold text-slate-400">Amount to Convert</label>
                        <button
                          type="button"
                          onClick={() => {
                            if (swapFromAsset === 'BTC') setSwapAmount(btcWallet.toString());
                            else if (swapFromAsset === 'RWF') setSwapAmount(rwfWallet.toString());
                            else setSwapAmount(usdWallet.toString());
                          }}
                          className="text-[10px] font-mono text-green-400 hover:underline cursor-pointer"
                        >
                          Use Max Balance
                        </button>
                      </div>
                      <div className="relative">
                        <input
                          type="text"
                          required
                          value={swapAmount}
                          onChange={(e) => setSwapAmount(e.target.value)}
                          placeholder="e.g. 0.05"
                          className="w-full bg-[#1e1f25] border border-slate-700 focus:border-green-500 rounded-xl py-3.5 px-4 text-sm text-white font-mono font-bold"
                        />
                        <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-mono font-bold text-green-400">
                          {swapFromAsset}
                        </span>
                      </div>
                    </div>

                    {/* Dynamic conversion result indicator */}
                    <div className="p-4 bg-green-500/5 rounded-xl border border-green-500/10 space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-400 font-medium">Estimated exchange payout:</span>
                        <span className="text-white font-bold font-mono">
                          {(() => {
                            const amt = parseFloat(swapAmount) || 0;
                            if (amt <= 0) return '0.00';
                            let usdEquivalent = 0;
                            if (swapFromAsset === 'BTC') usdEquivalent = amt * 65000;
                            else if (swapFromAsset === 'RWF') usdEquivalent = amt / 1300;
                            else usdEquivalent = amt;

                            if (swapToAsset === 'BTC') return (usdEquivalent / 65000).toLocaleString(undefined, { maximumFractionDigits: 6 }) + ' BTC';
                            if (swapToAsset === 'RWF') return (usdEquivalent * 1300).toLocaleString(undefined, { maximumFractionDigits: 0 }) + ' RWF';
                            return '$' + usdEquivalent.toLocaleString(undefined, { maximumFractionDigits: 2 }) + ' USD';
                          })()}
                        </span>
                      </div>
                      <div className="flex justify-between text-[11px] text-slate-400">
                        <span>Dynamic liquidity spread:</span>
                        <span className="text-green-400 font-mono">Free Promo (0.00% fees)</span>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={swapLoading}
                      className="w-full bg-green-600 hover:bg-green-500 text-white font-sans font-bold py-3.5 px-6 rounded-xl text-sm transition-all duration-200 active:scale-[0.98] shadow-lg shadow-green-900/25 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {swapLoading ? (
                        <span>Processing Instant Swap...</span>
                      ) : (
                        <>
                          <span className="material-symbols-outlined text-lg leading-none">swap_calls</span>
                          Execute Swap Order on Stellar
                        </>
                      )}
                    </button>
                  </form>

                  {/* Right index rates stats */}
                  <div className="lg:col-span-5 space-y-6">
                    <div className="glass-card p-6 rounded-2xl border border-[#434752]/20 space-y-4">
                      <h4 className="text-xs font-mono font-bold uppercase text-[#aec6ff] tracking-wider">
                        Live FastPay Price Indexes
                      </h4>
                      
                      <div className="space-y-3 font-mono text-[11px]">
                        <div className="flex justify-between items-center py-2 border-b border-slate-800">
                          <span className="text-slate-400">1 BTC / USD</span>
                          <span className="text-white font-bold">$65,000.00 USD</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-slate-800">
                          <span className="text-slate-400">1 BTC / RWF</span>
                          <span className="text-white font-bold">85,000,000 RWF</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-slate-800">
                          <span className="text-slate-400">1 USD / RWF</span>
                          <span className="text-white font-bold">1,300.00 RWF</span>
                        </div>
                      </div>

                      <div className="bg-[#aec6ff]/5 p-4 rounded-xl border border-blue-900/30 text-[11px] text-[#c3c6d4] leading-relaxed">
                        <span className="font-sans font-bold text-white block mb-0.5">Automated Settlement:</span>
                        Conversions are executed directly on the Stellar Decentralized Exchange (SDX) for near-instant transaction settlement in RWF or USD cash values.
                      </div>
                    </div>

                    {/* Fast Actions Tips */}
                    <div className="p-5 border border-slate-800 rounded-2xl space-y-3">
                      <h5 className="text-xs font-bold text-white">How does it work?</h5>
                      <ul className="text-slate-400 space-y-2 text-[11px] list-disc list-inside">
                        <li>Choose to offramp BTC into domestic RWF mobile money.</li>
                        <li>Purchase Bitcoin quickly using pre-deposited USD or RWF.</li>
                        <li>Swapped assets are credited to your balances instantly.</li>
                      </ul>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          )}

          {dashboardSubTab === 'tickets' && (
            <div className="space-y-6">
              <div className="glass-card p-6 md:p-8 rounded-2xl border border-blue-500/15 text-left">
                <header className="mb-6 flex justify-between items-center flex-wrap gap-4">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <span className="material-symbols-outlined text-blue-400 font-bold">payments</span>
                      Direct Wallet Deposit Gate
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">Simulate instant ledger funding. Inject BTC, RWF, or USD directly into your secure customer keys.</p>
                  </div>
                  <div className="flex items-center gap-2 bg-[#1e1f25] border border-blue-950/30 rounded-lg py-1.5 px-3 text-[10px] font-mono font-semibold text-blue-400">
                    <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                    Stellar Vault Funding Active
                  </div>
                </header>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                  
                  {/* Left Form Panel */}
                  <form onSubmit={handleExecuteDeposit} className="md:col-span-7 space-y-6 bg-[#16171d]/80 p-6 rounded-2xl border border-slate-800">
                    <div className="space-y-4">
                      
                      {/* Asset choice */}
                      <div className="space-y-2">
                        <label className="text-xs font-mono font-bold text-slate-400">Select Asset to Fund</label>
                        <div className="grid grid-cols-3 gap-3">
                          {['BTC', 'RWF', 'USD'].map((asset) => (
                            <button
                              key={asset}
                              type="button"
                              onClick={() => {
                                setDepAsset(asset as 'BTC' | 'RWF' | 'USD');
                                if (asset === 'BTC') setDepAmount('0.05');
                                else if (asset === 'USD') setDepAmount('1500');
                                else setDepAmount('150000');
                              }}
                              className={`py-3 px-4 rounded-xl border font-mono font-bold text-xs transition-all cursor-pointer text-center ${
                                depAsset === asset
                                  ? 'bg-blue-600/15 border-blue-500 text-white shadow-md shadow-blue-500/10'
                                  : 'bg-[#1c1d24] border-slate-800 text-slate-400 hover:text-white'
                              }`}
                            >
                              {asset === 'BTC' ? 'Bitcoin' : asset === 'RWF' ? 'Francs (RWF)' : 'Dollars (USD)'}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Input Amount */}
                      <div className="space-y-2">
                        <label className="text-xs font-mono font-bold text-slate-400">Deposit Amount</label>
                        <div className="relative">
                          <input
                            type="text"
                            required
                            value={depAmount}
                            onChange={(e) => setDepAmount(e.target.value)}
                            placeholder="e.g. 150000"
                            className="w-full bg-[#1e1f25] border border-slate-700 focus:border-blue-500 rounded-xl py-3.5 px-4 text-sm text-white font-mono font-bold"
                          />
                          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-mono font-bold text-blue-400">
                            {depAsset}
                          </span>
                        </div>
                      </div>

                    </div>

                    <div className="p-4 bg-blue-500/5 rounded-xl border border-blue-500/10 text-xs text-slate-400 leading-relaxed">
                      <span className="font-sans font-bold text-white block mb-0.5">Sandbox Integration Node:</span>
                      Since you are in a sandbox preview, executing this deposit will automatically bypass international clearings and immediately increment your local wallet balance on Stellar.
                    </div>

                    <button
                      type="submit"
                      disabled={depLoading}
                      className="w-full bg-blue-600 hover:bg-blue-500 text-white font-sans font-bold py-3.5 px-6 rounded-xl text-sm transition-all duration-200 active:scale-[0.98] shadow-lg shadow-blue-900/25 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {depLoading ? (
                        <span>Triggering Ledger Deposit...</span>
                      ) : (
                        <>
                          <span className="material-symbols-outlined text-lg leading-none">add_circle</span>
                          Approve Sandbox Deposit
                        </>
                      )}
                    </button>
                  </form>

                  {/* Right information Panel */}
                  <div className="md:col-span-5 space-y-4">
                    <div className="border border-slate-800 p-5 rounded-2xl space-y-3">
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">My Asset Addresses</h4>
                      
                      <div className="space-y-3 text-[10px] font-mono leading-relaxed">
                        <div className="p-3 bg-slate-900/20 rounded-lg space-y-1">
                          <span className="text-slate-500 font-bold block">BTC Deposit Vault:</span>
                          <span className="text-slate-300 block truncate">bc1qxy2kgdygjrsqp63773ndvdfg2h1v</span>
                        </div>
                        <div className="p-3 bg-slate-900/20 rounded-lg space-y-1">
                          <span className="text-slate-500 font-bold block">Stellar Anchor Wallet Key:</span>
                          <span className="text-slate-300 block truncate">GD3P...BKRLRWF9</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-5 border border-slate-800 rounded-2xl space-y-2">
                      <h5 className="text-[11px] font-bold text-white">Guaranteed settlements</h5>
                      <p className="text-slate-400 text-[10px] leading-relaxed">
                        Funds deposited here have direct liquidity correlation to local carrier payouts. Check MTN Settlement status for live off-ramping throughput statistics.
                      </p>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          )}

        </div>

      </main>

      {/* New Payment Dialog Modal */}
      {newPaymentOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-55 px-4">
          <div className="glass-card w-full max-w-md rounded-2xl border-2 border-[#aec6ff]/20 overflow-hidden shadow-2xl">
            <header className="p-6 bg-[#1e1f25] border-b border-[#434752]/20 flex justify-between items-center text-left">
              <div>
                <h3 className="text-base font-bold text-white">{t.addIncomingBtn} (BTC)</h3>
                <p className="text-[10px] text-[#c3c6d4] mt-1 font-mono">Simulates blockchain anchor receiving Bitcoin asset collateral</p>
              </div>
              <button 
                onClick={() => setNewPaymentOpen(false)}
                className="material-symbols-outlined text-[#c3c6d4] hover:text-white cursor-pointer"
              >
                close
              </button>
            </header>

            <form onSubmit={handleNewPaymentSubmit} className="p-6 space-y-4 text-left">
              <div className="space-y-1">
                <label className="text-xs font-mono font-medium text-[#c3c6d4]">{t.tableOrigin}</label>
                <select 
                  value={newOrigin}
                  onChange={(e) => setNewOrigin(e.target.value)}
                  className="w-full bg-[#0c0e13]/60 border border-[#434752]/40 rounded-xl px-4 py-3 text-xs text-[#e2e2ea]"
                >
                  <option value="Standard Bank (SA)">Standard Bank (SA)</option>
                  <option value="Ecobank (KE)">Ecobank (KE)</option>
                  <option value="Equity Bank (UG)">Equity Bank (UG)</option>
                  <option value="KCB (TZ)">KCB (TZ)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono font-medium text-[#c3c6d4]">{t.tableAssetValue} (BTC)</label>
                <input 
                  type="text"
                  value={newBtc}
                  onChange={(e) => setNewBtc(e.target.value)}
                  className="w-full bg-[#0c0e13]/60 border border-[#434752]/40 rounded-xl px-4 py-3 text-xs text-[#e2e2ea] font-mono custom-input"
                  placeholder="e.g. 0.05"
                />
              </div>

              <div className="bg-[#aec6ff]/5 p-4 rounded-xl border border-[#aec6ff]/10 text-xs font-mono">
                <p className="text-[#aec6ff] font-bold">Calculation Estimate:</p>
                <p className="mt-1 text-white">BTC/RWF rate: 85,000,000 RWF</p>
                <p className="mt-1 text-white font-bold">Setteling Payout RWF: {(parseFloat(newBtc || '0') * 85000000).toLocaleString()} RWF</p>
              </div>

              <footer className="pt-4 flex items-center justify-end gap-3 border-t border-[#434752]/20">
                <button 
                  type="button"
                  onClick={() => setNewPaymentOpen(false)}
                  className="px-4 py-2 border border-[#8d909d]/30 text-xs text-[#c3c6d4] rounded-lg cursor-pointer hover:bg-white/5"
                >
                  {"Cancel"}
                </button>
                <button 
                  type="submit"
                  className="px-5 py-2 bg-[#4472ca] hover:bg-[#5E7CE2] text-white font-semibold text-xs rounded-lg cursor-pointer"
                >
                  {t.addIncomingBtn}
                </button>
              </footer>
            </form>
          </div>
        </div>
      )}

      {/* Payout to Mobile Money Dialog Modal */}
      {mobilePayoutOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-55 px-4">
          <div className="glass-card w-full max-w-md rounded-2xl border-2 border-[#aec6ff]/20 overflow-hidden shadow-2xl">
            <header className="p-6 bg-[#1e1f25] border-b border-[#434752]/40 flex justify-between items-center text-left">
              <div>
                <h3 className="text-base font-bold text-white">{t.payoutToMobileBtn}</h3>
                <p className="text-[10px] text-[#c3c6d4] mt-1 font-mono">Triggers localized SIM telecom dispatch rails in RWF</p>
              </div>
              <button 
                onClick={() => setMobilePayoutOpen(false)}
                className="material-symbols-outlined text-[#c3c6d4] hover:text-white cursor-pointer"
              >
                close
              </button>
            </header>

            <form onSubmit={handleMobilePayoutSubmit} className="p-6 space-y-4 text-left">
              <div className="space-y-1">
                <label className="text-xs font-mono font-medium text-[#c3c6d4]">{"Carrier Telecom"}</label>
                <div className="grid grid-cols-2 gap-3">
                  <button 
                    type="button"
                    onClick={() => setPayoutNetwork('MTN MoMo')}
                    className={`p-3 rounded-xl border flex items-center justify-center text-xs font-semibold gap-2 transition-all cursor-pointer ${
                      payoutNetwork === 'MTN MoMo' 
                        ? 'bg-amber-400/10 border-amber-400 text-amber-400' 
                        : 'bg-[#0c0e13]/60 border-[#434752]/30 text-[#c3c6d4]'
                    }`}
                  >
                    MTN MoMo
                  </button>
                  <button 
                    type="button"
                    onClick={() => setPayoutNetwork('Airtel Money')}
                    className={`p-3 rounded-xl border flex items-center justify-center text-xs font-semibold gap-2 transition-all cursor-pointer ${
                      payoutNetwork === 'Airtel Money' 
                        ? 'bg-rose-500/10 border-rose-500 text-rose-500' 
                        : 'bg-[#0c0e13]/60 border-[#434752]/30 text-[#c3c6d4]'
                    }`}
                  >
                    Airtel Money
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono font-medium text-[#c3c6d4]">{"SIM Phone (Rwanda)"}</label>
                <input 
                  type="text"
                  value={payoutPhone}
                  onChange={(e) => setPayoutPhone(e.target.value)}
                  className="w-full bg-[#0c0e13]/60 border border-[#434752]/40 rounded-xl px-4 py-3 text-xs text-[#e2e2ea] font-mono custom-input"
                  placeholder="+250 788 123 456"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono font-medium text-[#c3c6d4]">{t.tableAmount}</label>
                <input 
                  type="text"
                  value={payoutAmount}
                  onChange={(e) => setPayoutAmount(e.target.value)}
                  className="w-full bg-[#0c0e13]/60 border border-[#434752]/40 rounded-xl px-4 py-3 text-xs text-[#e2e2ea] font-mono custom-input"
                  placeholder="e.g. 15000"
                />
              </div>

              <div className="bg-[#aec6ff]/5 p-4 rounded-xl border border-[#aec6ff]/10 text-xs font-mono">
                <p className="text-white">Active operational reserve: <span className="font-bold">{reserves.toLocaleString()} RWF</span></p>
                {parseInt(payoutAmount) > reserves && (
                  <p className="text-red-400 font-bold mt-1">⚠️ Outflow exceeds currently validated treasury balance limit!</p>
                )}
              </div>

              <footer className="pt-4 flex items-center justify-end gap-3 border-t border-[#434752]/20">
                <button 
                  type="button"
                  onClick={() => setMobilePayoutOpen(false)}
                  className="px-4 py-2 border border-[#8d909d]/30 text-xs text-[#c3c6d4] rounded-lg cursor-pointer hover:bg-white/5"
                >
                  {"Cancel"}
                </button>
                <button 
                  type="submit"
                  disabled={parseInt(payoutAmount) > reserves}
                  className="px-5 py-2 bg-[#4472ca] disabled:opacity-50 hover:bg-[#5E7CE2] text-white font-semibold text-xs rounded-lg cursor-pointer"
                >
                  {t.releaseBtn}
                </button>
              </footer>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
