import React, { useState, useRef, useEffect } from 'react';

export interface Language {
  code: string;
  name: string;
  nativeName: string;
}

// All major regional and global languages of the world
export const WORLD_LANGUAGES: Language[] = [
  { code: 'aa', name: 'Afar', nativeName: 'Afar' },
  { code: 'af', name: 'Afrikaans', nativeName: 'Afrikaans' },
  { code: 'sq', name: 'Albanian', nativeName: 'Shqip' },
  { code: 'am', name: 'Amharic', nativeName: 'አማርኛ' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية' },
  { code: 'hy', name: 'Armenian', nativeName: 'Հայերեն' },
  { code: 'as', name: 'Assamese', nativeName: 'অসমীয়া' },
  { code: 'ay', name: 'Aymara', nativeName: 'Aymar aru' },
  { code: 'az', name: 'Azerbaijani', nativeName: 'Azərbaycan dili' },
  { code: 'bm', name: 'Bambara', nativeName: 'Bamanankan' },
  { code: 'eu', name: 'Basque', nativeName: 'Euskara' },
  { code: 'be', name: 'Belarusian', nativeName: 'Беларуская' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা' },
  { code: 'bho', name: 'Bhojpuri', nativeName: 'भोजपुरी' },
  { code: 'bs', name: 'Bosnian', nativeName: 'Bosanski' },
  { code: 'bg', name: 'Bulgarian', nativeName: 'Български' },
  { code: 'ca', name: 'Catalan', nativeName: 'Català' },
  { code: 'ceb', name: 'Cebuano', nativeName: 'Binisaya' },
  { code: 'ny', name: 'Chichewa', nativeName: 'Chinyanja' },
  { code: 'zh', name: 'Chinese (Simplified)', nativeName: '中文 (简体)' },
  { code: 'zh-TW', name: 'Chinese (Traditional)', nativeName: '中文 (繁體)' },
  { code: 'co', name: 'Corsican', nativeName: 'Corsu' },
  { code: 'hr', name: 'Croatian', nativeName: 'Hrvatski' },
  { code: 'cs', name: 'Czech', nativeName: 'Čeština' },
  { code: 'da', name: 'Danish', nativeName: 'Dansk' },
  { code: 'dv', name: 'Dhivehi', nativeName: 'ދިވެހި' },
  { code: 'doi', name: 'Dogri', nativeName: 'डोगरी' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands' },
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'eo', name: 'Esperanto', nativeName: 'Esperanto' },
  { code: 'et', name: 'Estonian', nativeName: 'Eesti' },
  { code: 'ee', name: 'Ewe', nativeName: 'Eʋegbe' },
  { code: 'fil', name: 'Filipino (Tagalog)', nativeName: 'Tagalog' },
  { code: 'fi', name: 'Finnish', nativeName: 'Suomi' },
  { code: 'fr', name: 'French', nativeName: 'Français' },
  { code: 'fy', name: 'Frisian', nativeName: 'Frysk' },
  { code: 'gl', name: 'Galician', nativeName: 'Galego' },
  { code: 'ka', name: 'Georgian', nativeName: 'ქართული' },
  { code: 'de', name: 'German', nativeName: 'Deutsch' },
  { code: 'el', name: 'Greek', nativeName: 'Ελληνικά' },
  { code: 'gn', name: 'Guarani', nativeName: 'Avañe\'ẽ' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી' },
  { code: 'ht', name: 'Haitian Creole', nativeName: 'Kreyòl Ayisyen' },
  { code: 'ha', name: 'Hausa', nativeName: 'Hausa' },
  { code: 'haw', name: 'Hawaiian', nativeName: 'ʻŌlelo Hawaiʻi' },
  { code: 'he', name: 'Hebrew', nativeName: 'עברית' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
  { code: 'hmn', name: 'Hmong', nativeName: 'Hmoob' },
  { code: 'hu', name: 'Hungarian', nativeName: 'Magyar' },
  { code: 'is', name: 'Icelandic', nativeName: 'Íslenska' },
  { code: 'ig', name: 'Igbo', nativeName: 'Asụsụ Igbo' },
  { code: 'ilo', name: 'Ilocano', nativeName: 'Ilocano' },
  { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia' },
  { code: 'ga', name: 'Irish', nativeName: 'Gaeilge' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語' },
  { code: 'jv', name: 'Javanese', nativeName: 'Basa Jawa' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ' },
  { code: 'kk', name: 'Kazakh', nativeName: 'Қазақ тілі' },
  { code: 'km', name: 'Khmer', nativeName: 'ខ្មែរ' },
  { code: 'rw', name: 'Kinyarwanda', nativeName: 'Ikinyarwanda' },
  { code: 'gom', name: 'Konkani', nativeName: 'कोंकणी' },
  { code: 'ko', name: 'Korean', nativeName: '한국어' },
  { code: 'kri', name: 'Krio', nativeName: 'Krio' },
  { code: 'ku', name: 'Kurdish (Kurmanji)', nativeName: 'Kurdî (Kurmancî)' },
  { code: 'ckb', name: 'Kurdish (Sorani)', nativeName: 'Kurdî (Soranî)' },
  { code: 'ky', name: 'Kyrgyz', nativeName: 'Кыргызча' },
  { code: 'lo', name: 'Lao', nativeName: 'ລາວ' },
  { code: 'la', name: 'Latin', nativeName: 'Latina' },
  { code: 'lv', name: 'Latvian', nativeName: 'Latviešu' },
  { code: 'ln', name: 'Lingala', nativeName: 'Lingála' },
  { code: 'lt', name: 'Lithuanian', nativeName: 'Lietuvių' },
  { code: 'lg', name: 'Luganda', nativeName: 'Oluganda' },
  { code: 'lb', name: 'Luxembourgish', nativeName: 'Lëtzebuergesch' },
  { code: 'mk', name: 'Macedonian', nativeName: 'Македонски' },
  { code: 'mai', name: 'Maithili', nativeName: 'मैथिली' },
  { code: 'mg', name: 'Malagasy', nativeName: 'Fiteny Malagasy' },
  { code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം' },
  { code: 'mt', name: 'Maltese', nativeName: 'Malti' },
  { code: 'mi', name: 'Maori', nativeName: 'Te Reo Māori' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी' },
  { code: 'mni', name: 'Meiteilon (Manipuri)', nativeName: 'মৈতৈলোন্' },
  { code: 'mzo', name: 'Mizo', nativeName: 'Mizo ṭawng' },
  { code: 'mn', name: 'Mongolian', nativeName: 'Монгол хэл' },
  { code: 'my', name: 'Myanmar (Burmese)', nativeName: 'မြန်မာ' },
  { code: 'ne', name: 'Nepali', nativeName: 'नेपाली' },
  { code: 'no', name: 'Norwegian', nativeName: 'Norsk' },
  { code: 'or', name: 'Odia (Oriya)', nativeName: 'ଓଡ଼ିଆ' },
  { code: 'om', name: 'Oromo', nativeName: 'Afaan Oromoo' },
  { code: 'ps', name: 'Pashto', nativeName: 'پښتو' },
  { code: 'fa', name: 'Persian', nativeName: 'فارسی' },
  { code: 'pl', name: 'Polish', nativeName: 'Polski' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ' },
  { code: 'qu', name: 'Quechua', nativeName: 'Runasimi' },
  { code: 'ro', name: 'Romanian', nativeName: 'Română' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский' },
  { code: 'sm', name: 'Samoan', nativeName: 'Gagana Sāmoa' },
  { code: 'sa', name: 'Sanskrit', nativeName: 'संस्कृतम्' },
  { code: 'gd', name: 'Scots Gaelic', nativeName: 'Gàidhlig' },
  { code: 'nso', name: 'Sepedi', nativeName: 'Sepedi' },
  { code: 'sr', name: 'Serbian', nativeName: 'Српски' },
  { code: 'st', name: 'Sesotho', nativeName: 'Sesotho' },
  { code: 'sn', name: 'Shona', nativeName: 'chiShona' },
  { code: 'sd', name: 'Sindhi', nativeName: 'سنڌي' },
  { code: 'si', name: 'Sinhala', nativeName: 'සිංහල' },
  { code: 'sk', name: 'Slovak', nativeName: 'Slovenčina' },
  { code: 'sl', name: 'Slovenian', nativeName: 'Slovenščina' },
  { code: 'so', name: 'Somali', nativeName: 'Soomaali' },
  { code: 'es', name: 'Spanish', nativeName: 'Español' },
  { code: 'su', name: 'Sundanese', nativeName: 'Basa Sunda' },
  { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili' },
  { code: 'sv', name: 'Swedish', nativeName: 'Svenska' },
  { code: 'tg', name: 'Tajik', nativeName: 'Тоҷикӣ' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்' },
  { code: 'tt', name: 'Tatar', nativeName: 'Татар' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు' },
  { code: 'th', name: 'Thai', nativeName: 'ไทย' },
  { code: 'ti', name: 'Tigrinya', nativeName: 'ትግርኛ' },
  { code: 'ts', name: 'Tsonga', nativeName: 'Xitsonga' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe' },
  { code: 'tk', name: 'Turkmen', nativeName: 'Türkmen dili' },
  { code: 'ak', name: 'Twi (Akan)', nativeName: 'Twi' },
  { code: 'uk', name: 'Ukrainian', nativeName: 'Українська' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو' },
  { code: 'ug', name: 'Uyghur', nativeName: 'ئۇيغۇرچە' },
  { code: 'uz', name: 'Uzbek', nativeName: 'Oʻzbekcha' },
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt' },
  { code: 'cy', name: 'Welsh', nativeName: 'Cymraeg' },
  { code: 'xh', name: 'Xhosa', nativeName: 'isiXhosa' },
  { code: 'yi', name: 'Yiddish', nativeName: 'ייִדיש' },
  { code: 'yo', name: 'Yoruba', nativeName: 'Yorùbá' },
  { code: 'zu', name: 'Zulu', nativeName: 'isiZulu' }
];

interface LanguageSelectorProps {
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  variant?: 'navbar' | 'dashboard' | 'compact';
}

export default function LanguageSelector({ currentLanguage, onLanguageChange, variant = 'navbar' }: LanguageSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredLanguages = WORLD_LANGUAGES.filter(
    (lang) =>
      lang.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lang.nativeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lang.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSelect = (lang: Language) => {
    onLanguageChange(lang);
    setSearchQuery('');
    setIsOpen(false);
  };

  return (
    <div className="relative inline-block text-left" ref={dropdownRef} id={`lang-selector-${variant}`}>
      
      {variant === 'navbar' && (
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#434752]/30 hover:border-[#aec6ff]/50 bg-[#CFDEE7]/5 hover:bg-[#CFDEE7]/10 text-[#c3c6d4] hover:text-white transition-all duration-200 cursor-pointer text-xs font-mono font-bold uppercase"
        >
          <span className="material-symbols-outlined text-base">language</span>
          <span>{currentLanguage.code}</span>
          <span className="material-symbols-outlined text-[10px] select-none">arrow_drop_down</span>
        </button>
      )}

      {variant === 'dashboard' && (
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#aec6ff]/10 hover:bg-[#aec6ff]/25 border border-[#aec6ff]/20 text-[#c3c6d4] hover:text-[#aec6ff] transition-all duration-200 cursor-pointer text-xs font-mono font-bold"
        >
          <span className="material-symbols-outlined text-sm">language</span>
          <span className="uppercase">{currentLanguage.name} / {currentLanguage.code}</span>
          <span className="material-symbols-outlined text-[10px]">arrow_drop_down</span>
        </button>
      )}

      {variant === 'compact' && (
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="material-symbols-outlined text-[#c3c6d4] hover:text-white cursor-pointer transition-colors text-xl p-1 rounded-lg hover:bg-[#1e1f25]"
        >
          language
        </button>
      )}

      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 max-h-96 md:w-80 bg-[#1e1f25] border border-[#5E7CE2]/30 rounded-xl shadow-2xl z-55 overflow-hidden flex flex-col">
          <header className="p-3 border-b border-[#434752]/20 bg-[#1e1f25]">
            <div className="relative">
              <span className="material-symbols-outlined absolute left-2.5 top-1/2 -translate-y-1/2 text-[16px] text-[#8d909d]">
                search
              </span>
              <input
                type="text"
                placeholder="Search 130+ world languages..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#0c0e13] border border-[#434752]/40 rounded-lg py-2 pl-9 pr-3 text-xs text-[#e2e2ea] placeholder-[#8d909d]/60 outline-none focus:border-[#aec6ff]/60 font-sans"
                autoFocus
              />
            </div>
          </header>

          <div className="flex-grow overflow-y-auto max-h-60 scrollbar-thin divide-y divide-[#434752]/10">
            {filteredLanguages.length === 0 ? (
              <p className="p-4 text-center text-xs text-[#c3c6d4]/60 font-mono">No matching languages found.</p>
            ) : (
              filteredLanguages.map((lang) => {
                const isSelected = lang.code === currentLanguage.code;
                return (
                  <button
                    key={lang.code}
                    onClick={() => handleSelect(lang)}
                    className={`w-full text-left px-4 py-2.5 text-xs flex items-center justify-between transition-colors ${
                      isSelected
                        ? 'bg-[#173da4] text-white font-bold'
                        : 'text-[#c3c6d4] hover:bg-[#33353b]/30 hover:text-white'
                    }`}
                  >
                    <div className="flex flex-col text-left">
                      <span className="font-sans font-semibold text-white">{lang.name}</span>
                      <span className="text-[10px] text-[#c3c6d4]/60 font-mono">{lang.nativeName}</span>
                    </div>
                    <span className="font-mono text-[10px] font-bold uppercase tracking-wider bg-[#CFDEE7]/10 px-1.5 py-0.5 rounded border border-[#434752]/15">
                      {lang.code}
                    </span>
                  </button>
                );
              })
            )}
          </div>

          <footer className="bg-[#111319] p-2.5 border-t border-[#434752]/20 text-[10px] font-mono text-center text-[#c3c6d4]/60">
            International Payment Corridor Settings
          </footer>
        </div>
      )}
    </div>
  );
}
