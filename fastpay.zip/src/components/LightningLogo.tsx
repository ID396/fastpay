import React from 'react';

interface LightningLogoProps {
  className?: string;
}

export default function LightningLogo({ className = "h-8 w-8" }: LightningLogoProps) {
  return (
    <div className="relative flex items-center justify-center">
      {/* Neo glow backdrop */}
      <div className="absolute inset-0 bg-[#00f3ff] opacity-20 blur-md rounded-full scale-125 animate-pulse" />
      
      <svg 
        viewBox="0 0 24 24" 
        className={`${className} text-[#00f3ff] drop-shadow-[0_0_12px_rgba(0,243,255,0.9)] relative z-10`}
        stroke="currentColor" 
        strokeWidth="1.5" 
        strokeLinecap="round" 
        strokeLinejoin="round"
        fill="none"
      >
        {/* Dynamic inner color matrix */}
        <polygon 
          points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" 
          fill="rgba(0, 243, 255, 0.25)" 
        />
        {/* Main lightning path */}
        <polygon 
          points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" 
          className="stroke-[#00f3ff]"
        />
        
        {/* Constellation points replicating the digital particle effect of the user image */}
        <circle cx="13" cy="2" r="0.75" className="fill-white" />
        <circle cx="3" cy="14" r="0.75" className="fill-white" />
        <circle cx="12" cy="14" r="0.5" className="fill-white" />
        <circle cx="11" cy="22" r="0.75" className="fill-white" />
        <circle cx="21" cy="10" r="0.75" className="fill-white" />
        <circle cx="12" cy="10" r="0.5" className="fill-white" />
        
        {/* Intermediate micro stellar particles */}
        <line x1="13" y1="2" x2="11" y2="7" className="stroke-white/30 stroke-[0.5] stroke-dasharray-[1,1]" />
        <line x1="11" y1="22" x2="13" y2="17" className="stroke-white/30 stroke-[0.5] stroke-dasharray-[1,1]" />
        
        {/* Additional glowing dust particles */}
        <circle cx="15" cy="8" r="0.5" className="fill-[#00f3ff]/80 animate-ping" />
        <circle cx="9" cy="16" r="0.5" className="fill-[#00f3ff]/80 animate-pulse" />
      </svg>
    </div>
  );
}
