import React from 'react';
import { Tab } from '../types';
import LanguageSelector, { Language } from './LanguageSelector';
import { getTranslations } from '../locales';
import LightningLogo from './LightningLogo';

interface NavbarProps {
  currentTab: Tab;
  setCurrentTab: (tab: Tab) => void;
  onLogout?: () => void;
  isLoggedIn: boolean;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
}

export default function Navbar({ currentTab, setCurrentTab, isLoggedIn, onLogout, currentLanguage, onLanguageChange, theme, toggleTheme }: NavbarProps) {
  const t = getTranslations(currentLanguage.code);

  return (
    <nav className="fixed top-0 w-full z-50 bg-[#111319]/80 backdrop-blur-md border-b border-[#5E7CE2]/10">
      <div className="flex justify-between items-center px-6 md:px-10 py-4 max-w-7xl mx-auto">
        
        {/* Logo Branding */}
        <div 
          onClick={() => setCurrentTab('landing')} 
          className="flex items-center gap-3 cursor-pointer group active:scale-98 transition-transform"
          id="nav-logo"
        >
          <LightningLogo className="h-8 w-8" />
          <span className="text-xl font-bold text-[#aec6ff] tracking-tight group-hover:text-white transition-colors">
            FastPay
          </span>
        </div>

        {/* Links Alignment */}
        <div className="hidden md:flex gap-8 items-center" id="nav-desktop-links">
          <button 
            onClick={() => setCurrentTab('landing')}
            className={`font-medium text-sm transition-colors duration-200 cursor-pointer ${
              currentTab === 'landing' 
                ? 'text-[#aec6ff] border-b-2 border-[#aec6ff] pb-1 font-semibold' 
                : 'text-[#c3c6d4] hover:text-[#5E7CE2]'
            }`}
          >
            {t.solutionsMap}
          </button>
          
          <button 
            onClick={() => {
              // Scroll to mobile payout or show visual highlight
              setCurrentTab('landing');
              setTimeout(() => {
                document.getElementById('mobile-payments')?.scrollIntoView({ behavior: 'smooth' });
              }, 100);
            }}
            className="font-medium text-sm text-[#c3c6d4] hover:text-[#5E7CE2] transition-colors cursor-pointer"
          >
            {t.directPayouts}
          </button>

          <button 
            onClick={() => {
              if (isLoggedIn) {
                setCurrentTab('dashboard');
              } else {
                setCurrentTab('login');
              }
            }}
            className={`font-medium text-sm transition-colors duration-200 cursor-pointer ${
              currentTab === 'login' || currentTab === 'dashboard'
                ? 'text-[#aec6ff] border-b-2 border-[#aec6ff] pb-1 font-semibold' 
                : 'text-[#c3c6d4] hover:text-[#5E7CE2]'
            }`}
          >
            {isLoggedIn ? t.institutionPortal : t.portalSignIn}
          </button>
        </div>

        {/* Action Buttons & Quick Widgets */}
        <div className="flex items-center gap-4" id="nav-actions">
          <div className="hidden sm:flex items-center gap-3">
            <LanguageSelector 
              currentLanguage={currentLanguage} 
              onLanguageChange={onLanguageChange} 
              variant="navbar" 
            />
            <button 
              onClick={toggleTheme}
              className="material-symbols-outlined text-[#c3c6d4] hover:text-white cursor-pointer transition-colors text-xl p-1 rounded-lg hover:bg-[#1e1f25]"
              title={theme === 'dark' ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {theme === 'dark' ? 'light_mode' : 'dark_mode'}
            </button>
          </div>

          {isLoggedIn ? (
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setCurrentTab('dashboard')}
                className="bg-[#173da4] hover:bg-[#4472ca] text-[#9eb2ff] hover:text-white px-5 py-2 rounded-lg font-medium text-xs transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
              >
                <span className="material-symbols-outlined text-sm leading-none">account_balance</span>
                {t.dashboard}
              </button>
              <button 
                onClick={onLogout}
                className="text-[#c3c6d4] hover:text-[#ffb4ab] text-xs font-semibold px-2 py-1 transition-colors cursor-pointer"
              >
                {t.signOut}
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setCurrentTab('login')}
                className="text-[#c3c6d4] hover:text-white font-medium text-xs md:text-sm px-3 py-2 cursor-pointer transition-colors"
              >
                {t.signIn}
              </button>
              <button 
                onClick={() => setCurrentTab('login')}
                className="bg-[#4472ca] hover:bg-[#5E7CE2] text-white px-5 py-2 rounded-lg font-semibold text-xs md:text-sm transition-all active:scale-95 cursor-pointer shadow-md shadow-[#4472ca]/10"
              >
                {t.getStarted}
              </button>
            </div>
          )}
        </div>

      </div>
    </nav>
  );
}
