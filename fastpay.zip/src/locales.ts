export interface TranslationDict {
  // Common / Navbar
  solutionsMap: string;
  directPayouts: string;
  institutionPortal: string;
  portalSignIn: string;
  signOut: string;
  signIn: string;
  getStarted: string;
  dashboard: string;

  // Landing Page
  heroTitle1: string;
  heroTitle2: string;
  heroSubtitle: string;
  startAccepting: string;
  exploreHubs: string;
  liveRate: string;
  deliverySpeed: string;
  complianceAuditing: string;
  operationalNodes: string;
  operationalNodesSub: string;
  centralBankIntegrated: string;
  centralBankIntegratedSub: string;
  multisigProtocols: string;
  multisigProtocolsSub: string;
  mobileMoneyRails: string;
  directMobileTitle: string;
  directMobileSub: string;
  mtnSettlement: string;
  mtnSub: string;
  airtelSettlement: string;
  airtelSub: string;
  programmableContracts: string;
  programmableSub: string;
  registerInstruction: string;
  emergencySupport: string;

  // Portal Login
  institutionalAccess: string;
  loginSub: string;
  usernameField: string;
  passwordField: string;
  rememberMachine: string;
  forgotPassword: string;
  signInPortalBtn: string;
  loadingTokenGate: string;

  // Dashboard
  incomingBtc24h: string;
  rwfReserves: string;
  pendingApprovals: string;
  crossBorderQueue: string;
  tableTxId: string;
  tableOrigin: string;
  tableAssetValue: string;
  tableAmount: string;
  tableStatus: string;
  tableAction: string;
  releaseBtn: string;
  officersOnDuty: string;
  mobilePayoutStatus: string;
  addIncomingBtn: string;
  payoutToMobileBtn: string;
  systemOperational: string;
  viewAll: string;
  emailHistory: string;

  // Settings
  accountSettings: string;
  settingsSub: string;
  personalInfo: string;
  fullName: string;
  bioDesc: string;
  professionalDetails: string;
  orgName: string;
  socialConnections: string;
  securityAlerts: string;
  pushNotifications: string;
  twoFactorAuth: string;
  dailyEmailLogs: string;
  saveChanges: string;
  preferredLanguage: string;
  preferredLanguageSub: string;
}

export const TRANSLATIONS: { [langCode: string]: TranslationDict } = {
  en: {
    solutionsMap: "Exchange Hub",
    directPayouts: "Withdraw Cash",
    institutionPortal: "Customer Portal",
    portalSignIn: "Sign In as Customer",
    signOut: "Sign Out",
    signIn: "Sign In",
    getStarted: "Start Converting",
    dashboard: "Customer Dashboard",

    heroTitle1: "Bitcoin ⇄ Fiat Instant Swap.",
    heroTitle2: "Deposit BTC, RWF & US Dollars.",
    heroSubtitle: "Deposit funds in Bitcoin, Rwandan Francs (RWF), or US Dollars (USD) and instantly convert them at real-time Stellar rates with lowest fees and direct mobile payouts.",
    startAccepting: "Start Swap Converter",
    exploreHubs: "Explore Exchange Nodes",
    liveRate: "Live Conversion Indexes",
    deliverySpeed: "Instant Conversion Settlement",
    complianceAuditing: "Real-time Audited Safekeeping",
    operationalNodes: "Customer Conversion Gateways",
    operationalNodesSub: "FastPay gateways are fully backed by deep liquid reserves in Bitcoin, RWF and US Dollars, ensuring instant conversions and lightning fast payouts to mobile wallets.",
    centralBankIntegrated: "Regulatory Compliance Complied",
    centralBankIntegratedSub: "Direct integration with local fiat clearing anchors for secure, compliant, dual conversion transfers.",
    multisigProtocols: "Encrypted Account Custody",
    multisigProtocolsSub: "Your cryptographic account balances are shielded by multi-sig secure Stellar contracts for top-class security.",
    mobileMoneyRails: "Direct Mobile Money Withdrawals",
    directMobileTitle: "Direct-to-Wallet Onramp / Offramp",
    directMobileSub: "Convert between cryptographic assets and RWF/USD cash instantly. Offramp directly to MTN MoMo and Airtel Money mobile wallets in under 5 seconds.",
    mtnSettlement: "MTN MoMo Settlement",
    mtnSub: "Fully compatible with all MTN wallets in Rwanda. Zero redundant delay in conversion routing.",
    airtelSettlement: "Airtel Money Settlement",
    airtelSub: "Instant offramp transfers to Airtel Money SIM targets. Secured, verified accounts.",
    programmableContracts: "Automated Price Alerts",
    programmableSub: "Automate custom orders to buy or sell Bitcoin as soon as your designated RWF or USD valuation limits are hit.",
    registerInstruction: "Create a Customer Account",
    emergencySupport: "Customer Care Incident Desk",

    institutionalAccess: "Customer Exchange Access",
    loginSub: "Welcome back! Enter your login credentials to access your dashboard, balances, and conversion ledger.",
    usernameField: "Customer Username or Email",
    passwordField: "Password",
    rememberMachine: "Trust this device structure",
    forgotPassword: "Forgot Account Password?",
    signInPortalBtn: "Sign In to Client Wallet",
    loadingTokenGate: "Loading Customer Balances...",

    incomingBtc24h: "Bitcoin Wallet (BTC)",
    rwfReserves: "Rwandan Franc Wallet (RWF)",
    pendingApprovals: "US Dollar Wallet (USD)",
    crossBorderQueue: "My Conversion History Ledger",
    tableTxId: "Settle Hash ID",
    tableOrigin: "Conversion Mechanism",
    tableAssetValue: "BTC Volume",
    tableAmount: "Frictionless Amount",
    tableStatus: "Conversion Status",
    tableAction: "Details",
    releaseBtn: "Validate",
    officersOnDuty: "Custody Officers",
    mobilePayoutStatus: "SIM Offramp Status",
    addIncomingBtn: "Instant Deposit desk",
    payoutToMobileBtn: "Offline Cash Withdraw",
    systemOperational: "Customer Desk Operational",
    viewAll: "Show Historial Desk",
    emailHistory: "Account Logs",

    accountSettings: "My Customer Settings",
    settingsSub: "Customize your personal customer identity, verification limits, and daily security notifications.",
    personalInfo: "Personal Profile Details",
    fullName: "Customer Display Name",
    bioDesc: "Customer Description",
    professionalDetails: "Account Details",
    orgName: "Personal Affiliation Type",
    socialConnections: "My Web Links",
    securityAlerts: "Alert Notifications",
    pushNotifications: "Push Message Logs",
    twoFactorAuth: "Two-Factor Customer Security",
    dailyEmailLogs: "Email Transaction Receipts",
    saveChanges: "Save Profile Settings",
    preferredLanguage: "Interface Language",
    preferredLanguageSub: "Choose your preferred primary UI language to display your conversion desk dashboards."
  },
  rw: {
    solutionsMap: "Ibyerekeye / Ikarita",
    directPayouts: "Kwohereza Ako Kanya",
    institutionPortal: "Ihuriro ry'Ikigo",
    portalSignIn: "Kwinjira mu Ihuriro",
    signOut: "Sohoka",
    signIn: "Yinjira",
    getStarted: "Tangira Ushya",
    dashboard: "Ibiro Bikuru",

    heroTitle1: "Bitcoin Inyuramo. RWF Zisohoka.",
    heroTitle2: "Ahazaza H'amabanki muri Afrika.",
    heroSubtitle: "Koresha uburyo bwa mbaraga bwa Stellar blockchain amakoridoro yo kwohereza no kwakira amafaranga mu Rwanda mu masegonda make. Nta nzitizi, nta kiguzi kinini, umutekano wizewe ku bigo by'imari.",
    startAccepting: "Tangira Kwakira Crypto",
    exploreHubs: "Shakisha Urusobe rw'Ihuriro",
    liveRate: "Igipimo cy'Ikiguzi Ako Kanya",
    deliverySpeed: "Munsi y'Amasegonda 5",
    complianceAuditing: "Ikurikiza Amategeko ya BNR",
    operationalNodes: "Ihuriro ry'Ikwirakwiza Rikora",
    operationalNodesSub: "Ibyerekezo bya FastPay bishinze mu turere twose tw'ubukungu mu Rwanda. Ibyemezo byose byo mu nzego z'ibanze bishyigikiwe n'ububiko bw'amafaranga ako kanya.",
    centralBankIntegrated: "Ryahujwe na Banki Nkuru",
    centralBankIntegratedSub: "Guhuza imikorere ako kanya n'amategeko ya Banki Nkuru y'u Rwanda (BNR) mu kurwanya ikwirakwiza ry'amafaranga anyuranyije n'amategeko.",
    multisigProtocols: "Amasezerano asinyirwa n'Abantu Benshi",
    multisigProtocolsSub: "Umutekano wizewe ushyigikiwe n'amasezerano ya Stellar asaba abagenzuzi kwemeza ibyoherezwa babishaka cyangwa ku buryo bwikora.",
    mobileMoneyRails: "Genzura Imiyoboro ya Mobile Money",
    directMobileTitle: "Kwohereza kuri Mobile Money Ako Kanya",
    directMobileSub: "Huza imiyoboro mpuzamahanga ya crypto n'imiyoboro migari ya mobile money mu Rwanda. FastPay ihindura ako kanya crypto mu mafaranga y'u Rwanda (RWF).",
    mtnSettlement: "Kwakira kuri MTN MoMo",
    mtnSub: "Ikorana n'imiyoboro yose y'amatelefone mu Rwanda. Nta bubiko bunini busabwa kugira ngo utangire.",
    airtelSettlement: "Kwakira kuri Airtel Money",
    airtelSub: "Ihuza ku buryo bworoshye n'imikorere ya Airtel Rwanda. Ikiguzi cy'itumanaho ni gito cyane.",
    programmableContracts: "Amasezerano Yikora",
    programmableSub: "Koresha uburyo bwikora bwo kwishyura abakozi cyangwa abaguzi igihe cyose igipimo cya Bitcoin kigeze ku giciro cyateganyijwe mu mafaranga y'u Rwanda RWF.",
    registerInstruction: "Yandikisha Ihuriro ry'Ikigo cyanyu",
    emergencySupport: "Ubufasha bw'Itekinitiki bwihuse",

    institutionalAccess: "Kwinjira kw'Ikigo",
    loginSub: "Murakaza neza. Injiza ibyangombwa byawe by'umutekano kugira ngo ugere ku bikorwa by'ihuriro.",
    usernameField: "Imeli cyangwa Izina",
    passwordField: "Ijambobanga",
    rememberMachine: "Yibuke iri koranabuhanga",
    forgotPassword: "Waba wibagiwe ijambobanga?",
    signInPortalBtn: "Injira mu Ihuriro",
    loadingTokenGate: "Turagenzura ibyangombwa...",

    incomingBtc24h: "Bitcoin Yinjiye (amasaha 24)",
    rwfReserves: "Ububiko bwa RWF buhari",
    pendingApprovals: "Ibyemezo bitegerejwe",
    crossBorderQueue: "Urutonde rw'Ibyoherejwe (Kurekura Fiat)",
    tableTxId: "Inomero y'Icyoherejwe",
    tableOrigin: "Aho Biturutse",
    tableAssetValue: "Agaciro k'Umutungo",
    tableAmount: "Ay'u Rwanda (RWF)",
    tableStatus: "Imiterere",
    tableAction: "Igikorwa",
    releaseBtn: "Kurekura",
    officersOnDuty: "Abakozi bari ku Kazi",
    mobilePayoutStatus: "Imiterere y'Ibyoherejwe kuri Mobile",
    addIncomingBtn: "Kwinjiza Ishya",
    payoutToMobileBtn: "Kohereza kuri Mobile",
    systemOperational: "Ihuriro rirakora",
    viewAll: "Reba Byose",
    emailHistory: "Amateka kuri Imeli",

    accountSettings: "Igenamiterere ry'Ikoresha",
    settingsSub: "Genzura umwirondoro w'ikigo cyawe, imikono y'isinya, n'imipaka y'umutekano.",
    personalInfo: "Amakuru Rusange Yihariye",
    fullName: "Amazina Yose",
    bioDesc: "Ibisobanuro Bikuranga",
    professionalDetails: "Amakuru y'Umwuga",
    orgName: "Izina ry'Ikigo",
    socialConnections: "Imihuro y'Imbuga Nkoranyambaga",
    securityAlerts: "Umutekano n'Impuruza",
    pushNotifications: "Impuruza kuri Murandasi",
    twoFactorAuth: "Ingenzura rya Kabiri (2FA)",
    dailyEmailLogs: "Raporo z'Umutekano kuri Imeli",
    saveChanges: "Bika Ibyahinduwe",
    preferredLanguage: "Ururimi Rukoreshwa mu Rugendo",
    preferredLanguageSub: "Hitamo ururimi runyuranye rwa sisitemu akaba arirwo rushyirwa ku nkuta n'ibiro mukorera."
  },
  fr: {
    solutionsMap: "Solutions / Carte",
    directPayouts: "Paiements Directs",
    institutionPortal: "Portail Institutionnel",
    portalSignIn: "Connexion Portail",
    signOut: "Se Déconnecter",
    signIn: "Se Connecter",
    getStarted: "Démarrer",
    dashboard: "Tableau de bord",

    heroTitle1: "Bitcoin Entrant. Francs Rwandais Sortant.",
    heroTitle2: "L'Avenir de la Banque Africaine.",
    heroSubtitle: "Tirez parti des ancres du réseau Stellar pour des règlements liquides instantanés en RWF. Pas d'intermédiaires, des frais minimes et une sécurité institutionnelle.",
    startAccepting: "Accepter la Crypto",
    exploreHubs: "Explorer les Hubs",
    liveRate: "Taux de Conversion en Direct",
    deliverySpeed: "Livraison < 5 Secondes",
    complianceAuditing: "Conforme BNR Active",
    operationalNodes: "Nœuds de Compensation Opérationnels",
    operationalNodesSub: "Les ancres FastPay sont distribuées dans diverses régions du Rwanda. Les transactions sont garanties par des réserves de liquidités instantanées.",
    centralBankIntegrated: "Corridors de la Banque Centrale Intégrés",
    centralBankIntegratedSub: "Connexion directe avec la banque centrale du Rwanda (BNR) pour les contrôles réglementaires anti-blanchiment.",
    multisigProtocols: "Protocoles de Validation Multi-Sig",
    multisigProtocolsSub: "Sélection sécurisée via des contrats intelligents Stellar nécessitant la validation manuelle ou automatique des trésoriers.",
    mobileMoneyRails: "Consulter les canaux de Mobile Money",
    directMobileTitle: "Règlement Direct vers Mobile",
    directMobileSub: "Connectez les actifs cryptographiques directement aux plus grands réseaux de monnaie mobile locaux au Rwanda. FastPay convertit instantanément en RWF.",
    mtnSettlement: "Règlement MTN MoMo",
    mtnSub: "Prend en charge toutes les puces SIM actives au Rwanda. Aucune réserve excessive requise.",
    airtelSettlement: "Règlement Airtel Money",
    airtelSub: "S'intègre de manière transparente au réseau Airtel Rwanda avec des coûts réseau minimes.",
    programmableContracts: "Contrats Programmables Rapides",
    programmableSub: "Automatisez la facturation ou les dépôts des employés à l'aide d'instructions décentralisées dès que le Bitcoin atteint un certain seuil en RWF.",
    registerInstruction: "Enregistrer l'Institution",
    emergencySupport: "Support Technique d'Urgence",

    institutionalAccess: "Accès Institutionnel",
    loginSub: "Bon retour. Saisissez vos identifiants sécurisés pour accéder à l'interface de compensation locale.",
    usernameField: "Nom d'utilisateur ou Email",
    passwordField: "Mot de passe",
    rememberMachine: "Se souvenir de cette machine",
    forgotPassword: "Mot de passe oublié ?",
    signInPortalBtn: "Se connecter au Portail",
    loadingTokenGate: "Vérification en cours...",

    incomingBtc24h: "BTC Entrant (24h)",
    rwfReserves: "Réserves Opérationnelles RWF",
    pendingApprovals: "Approbations en attente",
    crossBorderQueue: "Files d'attente transfrontalière (Libération)",
    tableTxId: "ID Transaction",
    tableOrigin: "Hub d'Origine",
    tableAssetValue: "Valeur de l'Actif",
    tableAmount: "Montant RWF",
    tableStatus: "Statut",
    tableAction: "Action",
    releaseBtn: "Libérer",
    officersOnDuty: "Officiers de Garde",
    mobilePayoutStatus: "Statut Versements Mobile",
    addIncomingBtn: "Nouveau Paiement",
    payoutToMobileBtn: "Verser sur Mobile",
    systemOperational: "Portail Opérationnel",
    viewAll: "Voir Tout",
    emailHistory: "Historique Emails",

    accountSettings: "Paramètres du Compte",
    settingsSub: "Gérez votre identité institutionnelle, vos signatures de validation et vos alertes de sécurité.",
    personalInfo: "Informations Personnelles",
    fullName: "Nom Complet",
    bioDesc: "Description Bio",
    professionalDetails: "Détails Professionnels",
    orgName: "Nom de l'Organisation",
    socialConnections: "Liens de Connexion",
    securityAlerts: "Sécurité & Alertes",
    pushNotifications: "Notifications Push",
    twoFactorAuth: "Double Facteur (2FA)",
    dailyEmailLogs: "Rapports d'Audit Quotidiens",
    saveChanges: "Enregistrer",
    preferredLanguage: "Langue Préférée du Système",
    preferredLanguageSub: "Choisissez la langue globale pour l'ensemble des écrans et composants de votre interface."
  },
  sw: {
    solutionsMap: "Suluhisho / Ramani",
    directPayouts: "Malipo ya Moja kwa Moja",
    institutionPortal: "Tovuti ya Taasisi",
    portalSignIn: "Weka Kuingia",
    signOut: "Ondoka",
    signIn: "Ingia",
    getStarted: "Anza Sasa",
    dashboard: "Eneo la Kazi",

    heroTitle1: "Bitcoin Inaingia. Francs ya Rwanda Inatoka.",
    heroTitle2: "Mustakabali wa Benki za Afrika.",
    heroSubtitle: "Tumia mtandao dhabiti wa Stellar kufanya malipo ya haraka katika sarafu ya RWF nchini Rwanda. Hakuna udalali wa kimataifa, ada ndogo na usalama wa kiwango cha juu.",
    startAccepting: "Anza Kupokea Crypto",
    exploreHubs: "Gundua Mtandao Wetu",
    liveRate: "Kiwango cha Sasa cha Ubadilishaji",
    deliverySpeed: "Uwasilishaji Chini ya Sekunde 5",
    complianceAuditing: "Inafuata Sheria za BNR",
    operationalNodes: "Mifumo ya Kusafisha Fedha inayofanya kazi",
    operationalNodesSub: "Vituo vya FastPay vimesambazwa katika maeneo mbalimbali ya kiuchumi nchini Rwanda. Malipo yote yanaungwa mkono na akiba ya haraka ya RWF.",
    centralBankIntegrated: "Ushirikiano na Benki Kuu",
    centralBankIntegratedSub: "Mawasiliano ya moja kwa moja na benki kuu ya Rwanda (BNR) ili kuzuia utakatishaji wa fedha haramu.",
    multisigProtocols: "Itifaki za Sahihi za Pamoja",
    multisigProtocolsSub: "Usalama thabiti unaoungwa mkono na mikataba ya Stellar inayohitaji wakaguzi kuidhinisha malipo kwa mkono au kiotomatiki.",
    mobileMoneyRails: "Kagua mifumo ya Pesa ya Simu",
    directMobileTitle: "Malipo Moja kwa Moja kwenye Simu",
    directMobileSub: "Unganisha rasilimali za crypto moja kwa moja na mifumo mikubwa zaidi ya pesa za simu nchini Rwanda. FastPay inabadilisha crypto kuwa RWF papo hapo.",
    mtnSettlement: "Malipo ya MTN MoMo",
    mtnSub: "Inasaidia mifumo yote ya kadi za SIM nchini Rwanda. Hakuna haja ya kuweka akiba kubwa ili kuanza.",
    airtelSettlement: "Malipo ya Airtel Money",
    airtelSub: "Inajumuisha kwa urahisi mifumo ya Airtel Rwanda yenye gharama ndogo za upokeaji.",
    programmableContracts: "Mikataba Inayoratibiwa Haraka",
    programmableSub: "Fanya otomatiki malipo ya wafanyikazi au wachuuzi mara tu Bitcoin inapofikia kiwango kilichowekwa cha RWF ya Rwanda.",
    registerInstruction: "Sajili Taasisi Yako",
    emergencySupport: "Usaidizi wa Haraka wa Kiufundi",

    institutionalAccess: "Ufikiaji wa Taasisi",
    loginSub: "Karibu tena. Ingiza kitambulisho chako salama cha ufikiaji ili kufikia mfumo wa kusafisha malipo ya ndani.",
    usernameField: "Barua Pepe au Jina la Mtumiaji",
    passwordField: "Nywila",
    rememberMachine: "Kumbuka mashine hii",
    forgotPassword: "Umesahau Nywila ?",
    signInPortalBtn: "Ingia kwenye Tovuti",
    loadingTokenGate: "Inathibitisha uwasilishaji...",

    incomingBtc24h: "Inbound BTC (Masaa 24)",
    rwfReserves: "Operational RWF Reserves",
    pendingApprovals: "Uidhinishaji Unasubiri",
    crossBorderQueue: "Msururu wa Malipo ya Mipakani",
    tableTxId: "ID ya Muamala",
    tableOrigin: "Kituo cha Mwanzo",
    tableAssetValue: "Thamani ya Mali",
    tableAmount: "Kiasi cha RWF",
    tableStatus: "Hali",
    tableAction: "Kitendo",
    releaseBtn: "Toa Fedha",
    officersOnDuty: "Maafisa Kazini",
    mobilePayoutStatus: "Hali ya Malipo ya Simu",
    addIncomingBtn: "Malipo Mapya",
    payoutToMobileBtn: "Lipa kwenye Simu",
    systemOperational: "Tovuti Inafanya Kazi",
    viewAll: "Tazama Zote",
    emailHistory: "Historia ya Barua Pepe",

    accountSettings: "Mipangilio ya Akaunti",
    settingsSub: "Dhibiti utambulisho wako, saini za uidhinishaji na vikomo vya usalama wa akaunti.",
    personalInfo: "Habari Binafsi",
    fullName: "Majina Kamili",
    bioDesc: "Wasifu description",
    professionalDetails: "Maelezo ya Kitaalamu",
    orgName: "Jina la Taasisi",
    socialConnections: "Viunganishi vya Mitandao",
    securityAlerts: "Usalama na Arifa",
    pushNotifications: "Arifa za Moja kwa Moja",
    twoFactorAuth: "Ulinzi wa Hatua Mbili (2FA)",
    dailyEmailLogs: "Ripoti za Barua za Kila Siku",
    saveChanges: "Hifadhi Mabadiliko",
    preferredLanguage: "Lugha Pendwa ya Mfumo",
    preferredLanguageSub: "Chagua kutoka kwa lugha zote za ulimwengu kwa matumizi ya kiolesura chako salama cha kusafisha malipo."
  },
  es: {
    solutionsMap: "Soluciones / Mapa",
    directPayouts: "Pagos Directos",
    institutionPortal: "Portal Institucional",
    portalSignIn: "Iniciar Sesión",
    signOut: "Cerrar Sesión",
    signIn: "Ingresar",
    getStarted: "Comenzar",
    dashboard: "Panel de Control",

    heroTitle1: "Bitcoin Entrando. Francos Ruandeses Saliendo.",
    heroTitle2: "El Futuro de la Banca Africana.",
    heroSubtitle: "Aproveche los anclajes de red Stellar para liquidaciones líquidas instantáneas en RWF. Sin intermediarios, tarifas mínimas y seguridad de calidad institucional para Ruanda.",
    startAccepting: "Aceptar Criptomonedas",
    exploreHubs: "Explorar Nodos de Red",
    liveRate: "Tasa de Conversión en Vivo",
    deliverySpeed: "Entrega < 5 Segundos",
    complianceAuditing: "Conformidad Activa de BNR",
    operationalNodes: "Nodos de Compensación Activos",
    operationalNodesSub: "Los anclajes de FastPay están distribuidos por todo Ruanda. Todos los pagos están respaldados por una reserva líquida de RWF.",
    centralBankIntegrated: "Corredores del Banco Central Integrados",
    centralBankIntegratedSub: "Conexión directa con la compensación del Banco Central de Ruanda (BNR) para controles antilavado.",
    multisigProtocols: "Protocolos Multifirma (Multi-Sig)",
    multisigProtocolsSub: "Custodia segura respaldada por contratos inteligentes de Stellar que requieren firmas de validadores.",
    mobileMoneyRails: "Ver canales de dinero móvil",
    directMobileTitle: "Liquidación en Dinero Móvil",
    directMobileSub: "Conecte la liquidez de cripto directamente con los mayores operadores móviles locales de Ruanda de forma instantánea.",
    mtnSettlement: "Liquidación MTN MoMo",
    mtnSub: "Soporta todas las tarjetas SIM de Ruanda. Cero reservas forzadas requeridas.",
    airtelSettlement: "Liquidación Airtel Money",
    airtelSub: "Excelente integración con los canales de Airtel Ruanda con costos mínimos.",
    programmableContracts: "Contratos Programables Rápidos",
    programmableSub: "Automatice pagos a empleados o proveedores tan pronto como el precio del Bitcoin alcance ciertas cotizaciones en RWF.",
    registerInstruction: "Registrar Nueva Institución",
    emergencySupport: "Soporte Técnico de Emergencia",

    institutionalAccess: "Acceso Institucional",
    loginSub: "Bienvenido de vuelta. Ingrese sus credenciales seguras para acceder al sistema de compensación regional.",
    usernameField: "Usuario o Correo Electrónico",
    passwordField: "Contraseña",
    rememberMachine: "Recordar este dispositivo",
    forgotPassword: "¿Olvidó su contraseña?",
    signInPortalBtn: "Entrar al Portal",
    loadingTokenGate: "Comprobando credenciales...",

    incomingBtc24h: "BTC Entrante (24h)",
    rwfReserves: "Reservas de RWF Operativas",
    pendingApprovals: "Aprobaciones Pendientes",
    crossBorderQueue: "Cola transfronteriza (Liberación de Fiat)",
    tableTxId: "ID de Transacción",
    tableOrigin: "Nodo Origen",
    tableAssetValue: "Cantidad",
    tableAmount: "Monto RWF",
    tableStatus: "Estado",
    tableAction: "Acción",
    releaseBtn: "Liberar",
    officersOnDuty: "Oficiales de Turno",
    mobilePayoutStatus: "Estado de Pagos Móvil",
    addIncomingBtn: "Nuevo Pago",
    payoutToMobileBtn: "Pago a Móvil",
    systemOperational: "Portal Operativo",
    viewAll: "Ver Todo",
    emailHistory: "Historial de Correo",

    accountSettings: "Configuración de la Cuenta",
    settingsSub: "Organice su identidad institucional, firmas del validador y alarmas de seguridad.",
    personalInfo: "Información Personal",
    fullName: "Nombre Completo",
    bioDesc: "Descripción de Perfil",
    professionalDetails: "Details de Empleo",
    orgName: "Nombre de la Organización",
    socialConnections: "Enlaces Sociales",
    securityAlerts: "Seguridad y Notificaciones",
    pushNotifications: "Notificaciones Push",
    twoFactorAuth: "Autenticación Doble (2FA)",
    dailyEmailLogs: "Reporte Diario de Correo",
    saveChanges: "Guardar Cambios",
    preferredLanguage: "Idioma Preferido de Sistema",
    preferredLanguageSub: "Seleccione entre todos los idiomas del mundo para renderizar su dashboard de clearing."
  }
};

/**
 * Helper definition to fetch standard localized strings with safe fallback to English
 */
export function getTranslations(langCode: string): TranslationDict {
  return TRANSLATIONS[langCode] || TRANSLATIONS.en;
}
