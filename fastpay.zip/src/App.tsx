import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import LandingPage from './components/LandingPage';
import PortalLogin from './components/PortalLogin';
import Dashboard from './components/Dashboard';
import Settings from './components/Settings';
import Chatbot from './components/Chatbot';
import { Tab } from './types';
import { Language } from './components/LanguageSelector';

const LOCALIZED_ALERTS: { [key: string]: { greeting: string, text: string } } = {
  en: { greeting: "Language Changed", text: "Cross-border payment clearing interface is now configured to English." },
  fr: { greeting: "Langue modifiée", text: "L'interface de compensation des paiements est maintenant configurée en Français." },
  rw: { greeting: "Indimi Zahinduwe", text: "Imyanya yose y'ihuriro rya koridoro yahinduwe mu Kinyarwanda." },
  sw: { greeting: "Lugha Imebadilishwa", text: "Kiolesura cha kusafisha malipo sasa kimesanidiwa kwa Kiswahili." },
  es: { greeting: "Idioma cambiado", text: "La interfaz de compensación de pagos ahora está configurada en Español." },
  zh: { greeting: "语言已更改", text: "跨境支付清算界面现已配置为中文（简体）。" },
  ar: { greeting: "تم تغيير اللغة", text: "تم تكوين واجهة تسوية المدفوعات عبر الحدود إلى اللغة العربية الآن." },
  de: { greeting: "Sprache geändert", text: "Die Schnittstelle für den grenzübeschreitenden Zahlungsverkehr ist jetzt auf Deutsch eingestellt." },
  pt: { greeting: "Idioma alterado", text: "A interface do corredor de pagamentos transfronteiriços está configurada para Português." },
  ja: { greeting: "言語を変更しました", text: "クロスボーダー決済清算インターフェースが日本語に設定されました。" }
};

export default function App() {
  const [currentTab, setCurrentTab] = useState<Tab>('landing');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [profileName, setProfileName] = useState('Theogene Rukundo');
  const [organisationName, setOrganisationName] = useState('Personal Client Wallet');

  // Theme configuration state
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('theme');
    if (saved === 'dark' || saved === 'light') return saved;
    return 'dark'; // default to dark
  });

  const toggleTheme = () => {
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'light') {
      root.classList.add('light');
    } else {
      root.classList.remove('light');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  // Language configuration state
  const [currentLanguage, setCurrentLanguage] = useState<Language>({
    code: 'en',
    name: 'English',
    nativeName: 'English'
  });
  const [toast, setToast] = useState<{ greeting: string; text: string } | null>(null);

  const handleLanguageChange = (lang: Language) => {
    setCurrentLanguage(lang);
    const alertConfig = LOCALIZED_ALERTS[lang.code] || {
      greeting: "Language Configured",
      text: `Portal clearing interface now configured to ${lang.name} (${lang.nativeName}).`
    };
    setToast(alertConfig);
  };

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Multi-user/Validator sign - in simulator
  const handleLoginSuccess = (name: string, org: string) => {
    setIsLoggedIn(true);
    setProfileName(name);
    setOrganisationName(org);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentTab('landing');
  };

  const handleProfileUpdate = (name: string, org: string) => {
    setProfileName(name);
    setOrganisationName(org);
  };

  return (
    <div className="font-sans antialiased text-[#e2e2ea]">
      
      {/* Localized Notification Toast */}
      {toast && (
        <div 
          id="lang-change-toast"
          className="fixed top-20 right-6 md:right-10 bg-[#1e1f25]/95 border border-[#5E7CE2] p-4 rounded-xl shadow-[0_10px_30px_rgba(94,124,226,0.25)] z-55 max-w-sm flex items-start gap-3 animate-fade-in animate-slide-up"
        >
          <div className="w-8 h-8 rounded-full bg-[#173da4]/20 flex items-center justify-center text-[#aec6ff]">
            <span className="material-symbols-outlined text-lg">g_translate</span>
          </div>
          <div className="flex-grow text-left">
            <h4 className="font-sans font-bold text-xs text-white leading-tight mb-1">{toast.greeting}</h4>
            <p className="font-sans text-[11px] text-[#c3c6d4] leading-relaxed">{toast.text}</p>
          </div>
          <button 
            onClick={() => setToast(null)}
            className="text-[#c3c6d4] hover:text-white cursor-pointer"
          >
            <span className="material-symbols-outlined text-sm leading-none">close</span>
          </button>
        </div>
      )}

      {/* Hide general navigation top-bar inside full dashboard and settings sidebar layouts to keep layout spacious */}
      {(currentTab === 'landing' || currentTab === 'login') && (
        <Navbar 
          currentTab={currentTab} 
          setCurrentTab={setCurrentTab} 
          isLoggedIn={isLoggedIn}
          onLogout={handleLogout}
          currentLanguage={currentLanguage}
          onLanguageChange={handleLanguageChange}
          theme={theme}
          toggleTheme={toggleTheme}
        />
      )}

      {/* Dynamic Tab Switchers */}
      <div id="main-content-flow">
        {currentTab === 'landing' && (
          <LandingPage setCurrentTab={setCurrentTab} currentLanguage={currentLanguage} />
        )}

        {currentTab === 'login' && (
          <PortalLogin 
            setCurrentTab={setCurrentTab} 
            onLoginSuccess={handleLoginSuccess}
            currentLanguage={currentLanguage}
          />
        )}

        {currentTab === 'dashboard' && (
          <Dashboard 
            currentTab={currentTab}
            setCurrentTab={setCurrentTab}
            onLogout={handleLogout}
            profileName={profileName}
            organisationName={organisationName}
            currentLanguage={currentLanguage}
            onLanguageChange={handleLanguageChange}
            theme={theme}
            toggleTheme={toggleTheme}
          />
        )}

        {currentTab === 'settings' && (
          <Settings 
            setCurrentTab={setCurrentTab}
            profileName={profileName}
            organisationName={organisationName}
            onProfileUpdate={handleProfileUpdate}
            currentLanguage={currentLanguage}
            onLanguageChange={handleLanguageChange}
            theme={theme}
            toggleTheme={toggleTheme}
          />
        )}
      </div>

      {/* Globals Secure AI Chatbot Floating Box */}
      <Chatbot />

    </div>
  );
}
