export interface Transaction {
  id: string;
  originHub: string;
  assetValue: number;
  rwfAmount: number;
  status: 'Wait Fiat' | 'Released' | 'Pending';
  timestamp: string;
}

export interface Payout {
  phone: string;
  network: 'MTN MoMo' | 'Airtel Money';
  amount: number;
  status: 'Success' | 'Pending' | 'Failed';
  timestamp: string;
}

export interface Profile {
  fullName: string;
  role: string;
  bio: string;
  organisationName: string;
  githubUrl: string;
  linkedinUrl: string;
  notifications: boolean;
  twoFactorAuth: boolean;
  emailAlerts: boolean;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

export type Tab = 'landing' | 'login' | 'dashboard' | 'settings';
