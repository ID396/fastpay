import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Simple in-memory database to make FastPay completely functional and interactive
interface Transaction {
  id: string;
  originHub: string;
  assetValue: number;
  rwfAmount: number;
  status: 'Wait Fiat' | 'Released' | 'Pending';
  timestamp: string;
}

interface Payout {
  phone: string;
  network: 'MTN MoMo' | 'Airtel Money';
  amount: number;
  status: 'Success' | 'Pending' | 'Failed';
  timestamp: string;
}

interface Corridor {
  id: string;
  name: string;
  region: string;
  licenseCode: string;
  stellarAnchor: string;
  initialReserves: number;
  timestamp: string;
}

interface Ticket {
  id: string;
  institutionName: string;
  severity: 'Critical' | 'Major' | 'Minor';
  contact: string;
  message: string;
  status: 'Open' | 'Investigating' | 'Resolved';
  timestamp: string;
}

let profile = {
  fullName: "Theogene Rukundo",
  role: "Verified FastPay Customer",
  bio: "Personal client account. Converting and depositing Bitcoin ⇄ RWF / US Dollars instantly using automated Stellar ledger contracts.",
  organisationName: "Personal Client Wallet",
  githubUrl: "github.com/theogene",
  linkedinUrl: "linkedin.com/in/theogene-rukundo",
  notifications: true,
  twoFactorAuth: true,
  emailAlerts: true
};

// Customer-oriented live account balances
let customerBtcBalance = 0.4502;
let customerRwfBalance = 12850000;
let customerUsdBalance = 9450.00;

let transactions: Transaction[] = [
  { id: "STLR-992...F12", originHub: "Standard Bank (SA)", assetValue: 0.12, rwfAmount: 8120500, status: "Wait Fiat", timestamp: new Date().toISOString() },
  { id: "STLR-881...X04", originHub: "Ecobank (KE)", assetValue: 0.05, rwfAmount: 3383000, status: "Wait Fiat", timestamp: new Date().toISOString() },
  { id: "STLR-442...P99", originHub: "Equity Bank (UG)", assetValue: 0.08, rwfAmount: 5413200, status: "Wait Fiat", timestamp: new Date().toISOString() }
];

let payouts: Payout[] = [
  { phone: "+250 788 123 456", network: "MTN MoMo", amount: 15000, status: "Success", timestamp: new Date().toISOString() },
  { phone: "+250 733 987 654", network: "Airtel Money", amount: 2500, status: "Pending", timestamp: new Date().toISOString() }
];

let corridors: Corridor[] = [
  { id: "CORR-KGL-001", name: "Bank of Kigali", region: "Kigali Hub", licenseCode: "BNR-LIC-2026-BK1", stellarAnchor: "GBK...BKRRWF", initialReserves: 52000000, timestamp: new Date().toISOString() },
  { id: "CORR-GNY-002", name: "Standard Bank (SA)", region: "Gisenyi Corridor", licenseCode: "BNR-LIC-2026-SB2", stellarAnchor: "GSB...SARRWF", initialReserves: 45000000, timestamp: new Date().toISOString() },
  { id: "CORR-RBA-003", name: "Ecobank (KE)", region: "Rubavu Border Hub", licenseCode: "BNR-LIC-2026-EB3", stellarAnchor: "GEB...KERRWF", initialReserves: 30000000, timestamp: new Date().toISOString() },
];

let tickets: Ticket[] = [
  { id: "TCK-4819", institutionName: "Standard Bank (SA)", severity: "Minor", contact: "ops@standardbank.za", message: "Stellar anchor periodic ledger synchronization lag detected (approx 2s delay).", status: "Investigating", timestamp: new Date().toISOString() },
];

let reserves = 52000000;
let incomingBtc24h = 0.4502;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API - Get Profile info
  app.get("/api/profile", (req, res) => {
    res.json(profile);
  });

  // API - Save Profile Info
  app.post("/api/profile", (req, res) => {
    profile = { ...profile, ...req.body };
    res.json({ success: true, profile });
  });

  // API - Get corridors
  app.get("/api/corridors", (req, res) => {
    res.json(corridors);
  });

  // API - Register institution corridor
  app.post("/api/corridors", (req, res) => {
    const { name, region, licenseCode, stellarAnchor, initialReserves } = req.body;
    if (!name || !region || !stellarAnchor) {
      return res.status(400).json({ error: "Missing required corridor details" });
    }

    const newId = `CORR-${region.substring(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 899)}`;
    const newCorridor: Corridor = {
      id: newId,
      name,
      region,
      licenseCode: licenseCode || `BNR-LIC-2026-${Math.random().toString(36).substring(3, 7).toUpperCase()}`,
      stellarAnchor,
      initialReserves: parseInt(initialReserves) || 0,
      timestamp: new Date().toISOString()
    };

    corridors.unshift(newCorridor);
    
    if (newCorridor.initialReserves > 0) {
      reserves += newCorridor.initialReserves;
    }

    res.json({ success: true, corridor: newCorridor });
  });

  // API - Get Tickets
  app.get("/api/tickets", (req, res) => {
    res.json(tickets);
  });

  // API - Submit support ticket
  app.post("/api/tickets", (req, res) => {
    const { institutionName, severity, contact, message } = req.body;
    if (!institutionName || !contact || !message) {
      return res.status(400).json({ error: "Missing required support incident details" });
    }

    const tckId = `TCK-${Math.floor(1000 + Math.random() * 8999)}`;
    const newTicket: Ticket = {
      id: tckId,
      institutionName,
      severity: severity || "Minor",
      contact,
      message,
      status: "Open",
      timestamp: new Date().toISOString()
    };

    tickets.unshift(newTicket);
    res.json({ success: true, ticket: newTicket });
  });

  // API - Get Transactions & Stats
  app.get("/api/dashboard", (req, res) => {
    res.json({
      reserves,
      incomingBtc24h,
      transactions,
      payouts,
      corridors,
      tickets,
      customerBalances: {
        btc: customerBtcBalance,
        rwf: customerRwfBalance,
        usd: customerUsdBalance
      }
    });
  });

  // API - Customer Convert Asset
  app.post("/api/customer/convert", (req, res) => {
    const { fromAsset, toAsset, amount, convertedAmount } = req.body;
    const numericAmount = parseFloat(amount || "0");
    const numericConverted = parseFloat(convertedAmount || "0");

    if (numericAmount <= 0) {
      return res.status(400).json({ error: "Conversion amount must be greater than zero." });
    }

    // Balance check and deduction
    if (fromAsset === "BTC") {
      if (customerBtcBalance < numericAmount) {
        return res.status(400).json({ error: "Insufficient BTC balance for conversion." });
      }
      customerBtcBalance -= numericAmount;
    } else if (fromAsset === "RWF") {
      if (customerRwfBalance < numericAmount) {
        return res.status(400).json({ error: "Insufficient RWF balance for conversion." });
      }
      customerRwfBalance -= numericAmount;
    } else if (fromAsset === "USD") {
      if (customerUsdBalance < numericAmount) {
        return res.status(400).json({ error: "Insufficient USD balance for conversion." });
      }
      customerUsdBalance -= numericAmount;
    } else {
      return res.status(400).json({ error: "Invalid source asset type." });
    }

    // Add to converted asset
    if (toAsset === "BTC") {
      customerBtcBalance += numericConverted;
    } else if (toAsset === "RWF") {
      customerRwfBalance += numericConverted;
    } else if (toAsset === "USD") {
      customerUsdBalance += numericConverted;
    } else {
      return res.status(400).json({ error: "Invalid target asset type." });
    }

    // Create record in historic conversions/transactions queue
    const id = `CONV-${Math.floor(100 + Math.random() * 899)}...${Math.random().toString(16).substring(2, 5).toUpperCase()}`;
    const newTx: Transaction = {
      id,
      originHub: `Wallet Conversion (${fromAsset} ➜ ${toAsset})`,
      assetValue: fromAsset === "BTC" ? numericAmount : (toAsset === "BTC" ? numericConverted : 0),
      rwfAmount: fromAsset === "RWF" ? numericAmount : (toAsset === "RWF" ? numericConverted : 0),
      status: 'Released',
      timestamp: new Date().toISOString()
    };

    transactions.unshift(newTx);

    res.json({
      success: true,
      balances: {
        btc: customerBtcBalance,
        rwf: customerRwfBalance,
        usd: customerUsdBalance
      },
      newTx
    });
  });

  // API - Customer Direct Asset Deposit (Onramp / Offramp Initializer)
  app.post("/api/customer/deposit", (req, res) => {
    const { asset, amount } = req.body;
    const numericAmount = parseFloat(amount || "0");

    if (numericAmount <= 0) {
      return res.status(400).json({ error: "Deposit amount must be greater than zero." });
    }

    if (asset === "BTC") {
      customerBtcBalance += numericAmount;
    } else if (asset === "RWF") {
      customerRwfBalance += numericAmount;
    } else if (asset === "USD") {
      customerUsdBalance += numericAmount;
    } else {
      return res.status(400).json({ error: "Invalid deposit asset type." });
    }

    const id = `DEP-${Math.floor(100 + Math.random() * 899)}...${Math.random().toString(16).substring(2, 5).toUpperCase()}`;
    const newTx: Transaction = {
      id,
      originHub: `${asset} Direct Deposit`,
      assetValue: asset === "BTC" ? numericAmount : 0,
      rwfAmount: asset === "RWF" ? numericAmount : 0,
      status: 'Released',
      timestamp: new Date().toISOString()
    };

    transactions.unshift(newTx);

    res.json({
      success: true,
      balances: {
        btc: customerBtcBalance,
        rwf: customerRwfBalance,
        usd: customerUsdBalance
      },
      newTx
    });
  });

  // API - Release Transaction (Cross-border queue)
  app.post("/api/transactions/release", (req, res) => {
    const { id } = req.body;
    const tx = transactions.find(t => t.id === id);
    if (tx && tx.status === 'Wait Fiat') {
      tx.status = 'Released';
      // Deduct from operational reserves as it got released to the domestic fiat rail!
      reserves -= tx.rwfAmount;
      res.json({ success: true, tx, reserves });
    } else {
      res.status(400).json({ error: "Transaction not found or already released" });
    }
  });

  // API - New Payment (Incoming BTC)
  app.post("/api/transactions/new", (req, res) => {
    const { originHub, assetValue } = req.body;
    const rate = 85000000; // 1 BTC = 85M RWF
    const rwfAmount = Math.round(assetValue * rate);
    
    // Generate a stellar stylized tx id
    const hex = Math.random().toString(16).substring(2, 5).toUpperCase();
    const id = `STLR-${Math.floor(100 + Math.random() * 899)}...${hex}`;

    const newTx: Transaction = {
      id,
      originHub: originHub || "Standard Bank (SA)",
      assetValue: parseFloat(assetValue),
      rwfAmount,
      status: 'Wait Fiat',
      timestamp: new Date().toISOString()
    };

    transactions.unshift(newTx);
    // Add to reserves since we now have more collateral or received BTC asset which back reserves.
    // In actual flow, releasing deducts reserves. Let's add incoming to Reserves to show updates.
    reserves += rwfAmount;
    incomingBtc24h += parseFloat(assetValue);

    res.json({ success: true, newTx, stats: { reserves, incomingBtc24h } });
  });

  // API - Payout to Mobile Money
  app.post("/api/payouts/new", (req, res) => {
    const { phone, network, amount } = req.body;
    const cleanAmount = parseInt(amount);

    if (reserves < cleanAmount) {
      return res.status(400).json({ error: "Insufficient operational RWF reserves for payout" });
    }

    const newPayout: Payout = {
      phone,
      network: network || "MTN MoMo",
      amount: cleanAmount,
      status: 'Pending',
      timestamp: new Date().toISOString()
    };

    payouts.unshift(newPayout);
    reserves -= cleanAmount;

    // Simulate approval and success in 4 seconds
    setTimeout(() => {
      newPayout.status = 'Success';
    }, 4000);

    res.json({ success: true, newPayout, reserves });
  });

  // API - Ask AI Assistant (Gemini Secure Proxy)
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, history } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.startsWith("MY_")) {
        // Return a mock fallback response which contains high-quality, friendly details
        return res.json({
          text: `👋 **FastPay Assistant:** Welcome to the FastPay Institution Portal demo! 

I'm currently running in **Demo Mode** since your \`GEMINI_API_KEY\` isn't active in the secrets area yet. But I can perfectly explain the platform:

1. **How FastPay Settles in RWF**: By integrating the Stellar Network, international liquidity providers deposit stablecoins or Bitcoin into our Stellar anchors. These anchors connect directly to Rwanda local clearing corridors (such as BNR central clearing corridors or directly to MTN/Airtel networks) to dispatch localized funds in under 5 seconds with negligible friction.
2. **On-duty Officers**: We have multiple multi-sig security controllers: *Sarah Kamau* coordinates AML Compliance, *Jean Pierre* acts as Treasury validator, and *System Root* oversees security protocols.
3. **Queue releases**: In the **Dashboard Queue**, banking treasurers manually click 'Release' to dispatch pending RWF settlements to domestic banks.

Ask me any other question about compliance, API keys, operational limits, or setting up your Stellar core anchors!`
        });
      }

      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });

      // Simple chat completion using ai.models.generateContent containing system role
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [
          {
            role: "user",
            parts: [{ text: "You are the FastPay AI Assistant. Speak as an authority on FastPay, a Stellar-powered payment gateway settling crypto in Rwandan Francs (RWF). Be concise, helpful, and highly professional. Answer questions on Stellar anchors, mobile money (MTN MoMo / Airtel Money), multi-sig compliance, and operational treasury limits." }]
          },
          ...history.map((h: any) => ({
            role: h.role,
            parts: [{ text: h.text }]
          })),
          {
            role: "user",
            parts: [{ text: message }]
          }
        ],
      });

      res.json({ text: response.text });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message || "Failed to trigger AI" });
    }
  });

  // Rates endpoint
  app.get("/api/rates", (req, res) => {
    res.json({
      btc_rwf: 85000000 + Math.floor((Math.random() - 0.5) * 40000),
      last_updated: new Date().toISOString(),
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server loaded successfully on port ${PORT}`);
  });
}

startServer();
